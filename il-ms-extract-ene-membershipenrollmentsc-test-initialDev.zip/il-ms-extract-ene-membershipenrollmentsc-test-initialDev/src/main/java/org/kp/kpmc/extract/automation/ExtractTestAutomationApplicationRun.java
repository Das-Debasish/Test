package org.kp.kpmc.extract.automation;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Component
public class ExtractTestAutomationApplicationRun implements ApplicationRunner {

//    @Autowired
//    ExtractTestAutomationService autoService;

    @Override
    public void run(ApplicationArguments args) throws Exception {
	String[] inputArgs = args.getSourceArgs();
//	autoService.uploadToInboundAndGetExtractFromOutbound(inputArgs[0], ExtractTestAutomationApplicationRun.class);
    }
}
