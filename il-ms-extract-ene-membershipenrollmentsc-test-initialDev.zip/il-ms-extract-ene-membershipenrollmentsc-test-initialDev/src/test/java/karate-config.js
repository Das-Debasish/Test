function fn(){
	var keyEnv = karate.env;
	karate.log('karate.env system property was:', keyEnv);
	var config = {
		refFileNameLocation: "src/test/resources/outbound/",
		refFilename:"mebership_enrollment_sc_20210713100051.txt",
		driverClassName: "",
		url: "",
		username: "",
		password: "",
};	
if(keyEnv=='JPT'){
	karate.log('karate.env system property was in JPT as:', keyEnv);
	config.driverClassName="oracle.jdbc.OracleDriver";
	config.url = "jdbc:oracle:thin:@//scan-pzendb181x.pldc.kp.org:1521/MCHUBDV3.pldc.kp.org";
	config.username = "appuser";
	config.password = "Kpifapps123";
}else if (keyEnv == 'DIT') {
	karate.log('karate.env system property was in DIT as:', keyEnv);
	config.driverClassName="oracle.jdbc.OracleDriver";
	config.url = "jdbc:oracle:thin:@//scan-pzendb181x.pldc.kp.org:1521/MCHUBDV3.pldc.kp.org";
	config.username = "appuser";
	config.password = "Kpifapps123";
}else {
	karate.log('karate.env system property was in DEV as:', keyEnv);
	config.driverClassName="oracle.jdbc.OracleDriver";
	config.url = "jdbc:oracle:thin:@//scan-pzendb181x.pldc.kp.org:1521/MCHUBDV3.pldc.kp.org";
	config.username = "appuser";
	config.password = "Kpifapps123";
}
return config;
	
}
