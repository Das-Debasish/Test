package org.kp.ene.membershipenrollment;

public class EnrollmentFieldsDatahub {

    private String NEDIRecordType;
    private String exchangeType;
    private String batch_Ref_834;
    private String NEDI_Batch_Generated_Time;
    private String NEDI_Batch_Processing_Time;
    private String NEDITOMAG_Record_Length;
    private String KAISER_REGION;
    private String RECORD_TYPE;
    private String RMS_GROUP_NO;
    private String RMS_SUBGROUP;
    private String RMS_BILLGROUP;
    private String EXCHANGE_QHP_ID;
    private String CONTRACT;
    private String CONTRACT_OPTION1;
    private String CONTRACT_OPTION2;
    private String CONTRACT_OPTION3;
    private String ACTIVITY_DATE;
    private String MAINT_TYPE_CODE_Health_Coverage_834;
    private String TRANS_TYPE_3;
    private String RECORD_CODE_3;
    private String MRN_PREFIX_3;
    private String MRN_HRN;

    private String FAN_PREFIX;
    private String FAN;
    private String MEDI_CAL_NBR;
    private String LAST_NAME;
    private String FIRST_NAME;
    private String MIDDLE_NAME;
    private String PREFIX_NAME;
    private String TITLE_NAME;
    private String DISPLAY_NAME;
    private String ACCOUNT_ROLE;
    private String SUBSCRIBERLESS_FLAG;
    private String BIRTH_DATE;
    private String MARITAL_STATUS;
    private String GENDER_CODE;
    private String MEDICARE_STATUS;
    private String SPECIAL_DEP_STATUS_Student;
    private String SPECIAL_DEP_STATUS_Handicap;
    private String NBR_IN_FAMILY;
    private String SUB_SSN;
    private String MEM_SSN;
    private String SUB_EMPL_ID_SUP;
    private String SUB_EMPL_ID;
    private String SUPPLEMENTAL_ID;
    private String FS_EMPLOYER_ID;
    private String EMPLOYER_NAME;
    private String EMPLOY_STATUS;
    private String HIRE_DATE;
    private String HOME_PHONE;
    private String HOME_PHONE_EXTENSION;
    private String WORK_PHONE;
    private String WORK_PHONE_EXTENSION;
    private String OCCUPATIONAL_TITLE;
    private String ADDRESS_1;
    private String ADDRESS_2;
    private String CARE_OF;
    private String CITY;
    private String COUNTY;
    private String STATE;
    private String ZIP_CODE_1;
    private String ZIP_CODE_2;
    private String COUNTRY;
    private String ENROLL_REASON;
    private String ENR_START_DATE;
    private String SIGNATURE_DATE;
    private String TERM_REASON;
    private String TERM_EFF_DATE;
    private String COBRA_MONTHS;
    private String COBRA_EFF_DATE;
    private String CUR_ELIGIBILITY;
    private String CUR_DUES_AMT;
    private String CUR_COVERAGE_LEVEL_CODE;
    private String LANGUAGE_SPOKEN;
    private String LANGUAGE_WRITTEN;
    private String ETHNICITY;
    private String EMPR_MDCR_IN;
    private String member_Exchange_Id;
    private String subscriber_Exchange_Id;
    private String coverage_attribute;
    private String tobacco_Use_Indicator;
    private String tobacco_Use_Indicator_effective_date;
    private String subsidy_Indicator;
    private String TAP_COVERAGE_PREMIUM_RATE_EXCHANGE_CSR_AMOUNT;
    private String subsidy_Indicator_effective_date;
    private String Max_TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE;
    private String TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_END_DATE;
    private String TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE;
    private String individual_Email_address;

    public EnrollmentFieldsDatahub(String NEDIRecordType, String exchangeType, String batch_Ref_834,
	    String NEDI_Batch_Generated_Time, String NEDI_Batch_Processing_Time, String NEDITOMAG_Record_Length,
	    String KAISER_REGION, String RECORD_TYPE, String RMS_GROUP_NO, String RMS_SUBGROUP, String RMS_BILLGROUP,
	    String EXCHANGE_QHP_ID, String CONTRACT, String CONTRACT_OPTION1, String CONTRACT_OPTION2,
	    String CONTRACT_OPTION3, String ACTIVITY_DATE, String MAINT_TYPE_CODE_Health_Coverage_834,
	    String TRANS_TYPE_3, String RECORD_CODE_3, String MRN_PREFIX_3, String MRN_HRN, String FAN_PREFIX,
	    String FAN, String MEDI_CAL_NBR, String LAST_NAME, String FIRST_NAME, String MIDDLE_NAME,
	    String PREFIX_NAME, String TITLE_NAME, String DISPLAY_NAME, String ACCOUNT_ROLE, String SUBSCRIBERLESS_FLAG,
	    String BIRTH_DATE, String MARITAL_STATUS, String GENDER_CODE, String MEDICARE_STATUS,
	    String SPECIAL_DEP_STATUS_Student, String SPECIAL_DEP_STATUS_Handicap, String NBR_IN_FAMILY, String SUB_SSN,
	    String MEM_SSN, String SUB_EMPL_ID_SUP, String SUB_EMPL_ID, String SUPPLEMENTAL_ID, String FS_EMPLOYER_ID,
	    String EMPLOYER_NAME, String EMPLOY_STATUS, String HIRE_DATE, String HOME_PHONE,
	    String HOME_PHONE_EXTENSION, String WORK_PHONE, String WORK_PHONE_EXTENSION, String OCCUPATIONAL_TITLE,
	    String ADDRESS_1, String ADDRESS_2, String CARE_OF, String CITY, String COUNTY, String STATE,
	    String ZIP_CODE_1, String ZIP_CODE_2, String COUNTRY, String ENROLL_REASON, String ENR_START_DATE,
	    String SIGNATURE_DATE, String TERM_REASON, String TERM_EFF_DATE, String COBRA_MONTHS, String COBRA_EFF_DATE,
	    String CUR_ELIGIBILITY, String CUR_DUES_AMT, String CUR_COVERAGE_LEVEL_CODE, String LANGUAGE_SPOKEN,
	    String LANGUAGE_WRITTEN, String ETHNICITY, String EMPR_MDCR_IN, String member_Exchange_Id,
	    String subscriber_Exchange_Id, String coverage_attribute, String tobacco_Use_Indicator,
	    String tobacco_Use_Indicator_effective_date, String subsidy_Indicator,
	    String TAP_COVERAGE_PREMIUM_RATE_EXCHANGE_CSR_AMOUNT, String subsidy_Indicator_effective_date,
	    String Max_TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE,
	    String TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_END_DATE, String TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE,
	    String individual_Email_address) {

	super();
	this.NEDIRecordType = NEDIRecordType;
	this.exchangeType = exchangeType;
	this.batch_Ref_834 = batch_Ref_834;
	this.NEDI_Batch_Generated_Time = NEDI_Batch_Generated_Time;
	this.NEDI_Batch_Processing_Time = NEDI_Batch_Processing_Time;
	this.NEDITOMAG_Record_Length = NEDITOMAG_Record_Length;
	this.KAISER_REGION = KAISER_REGION;
	this.RECORD_TYPE = RECORD_TYPE;
	this.RMS_GROUP_NO = RMS_GROUP_NO;
	this.RMS_SUBGROUP = RMS_SUBGROUP;
	this.RMS_BILLGROUP = RMS_BILLGROUP;
	this.EXCHANGE_QHP_ID = EXCHANGE_QHP_ID;
	this.CONTRACT = CONTRACT;
	this.CONTRACT_OPTION1 = CONTRACT_OPTION1;
	this.CONTRACT_OPTION2 = CONTRACT_OPTION2;
	this.CONTRACT_OPTION3 = CONTRACT_OPTION3;
	this.ACTIVITY_DATE = ACTIVITY_DATE;
	this.MAINT_TYPE_CODE_Health_Coverage_834 = MAINT_TYPE_CODE_Health_Coverage_834;
	this.TRANS_TYPE_3 = TRANS_TYPE_3;
	this.RECORD_CODE_3 = RECORD_CODE_3;
	this.MRN_PREFIX_3 = MRN_PREFIX_3;
	this.MRN_HRN = MRN_HRN;
	this.FAN_PREFIX = FAN_PREFIX;
	this.FAN = FAN;
	this.MEDI_CAL_NBR = MEDI_CAL_NBR;
	this.LAST_NAME = LAST_NAME;
	this.FIRST_NAME = FIRST_NAME;
	this.MIDDLE_NAME = MIDDLE_NAME;
	this.PREFIX_NAME = PREFIX_NAME;
	this.TITLE_NAME = TITLE_NAME;
	this.DISPLAY_NAME = DISPLAY_NAME;
	this.ACCOUNT_ROLE = ACCOUNT_ROLE;
	this.SUBSCRIBERLESS_FLAG = SUBSCRIBERLESS_FLAG;
	this.BIRTH_DATE = BIRTH_DATE;
	this.MARITAL_STATUS = MARITAL_STATUS;
	this.GENDER_CODE = GENDER_CODE;
	this.MEDICARE_STATUS = MEDICARE_STATUS;
	this.SPECIAL_DEP_STATUS_Student = SPECIAL_DEP_STATUS_Student;
	this.SPECIAL_DEP_STATUS_Handicap = SPECIAL_DEP_STATUS_Handicap;
	this.NBR_IN_FAMILY = NBR_IN_FAMILY;
	this.SUB_SSN = SUB_SSN;
	this.MEM_SSN = MEM_SSN;
	this.SUB_EMPL_ID_SUP = SUB_EMPL_ID_SUP;
	this.SUB_EMPL_ID = SUB_EMPL_ID;
	this.SUPPLEMENTAL_ID = SUPPLEMENTAL_ID;
	this.FS_EMPLOYER_ID = FS_EMPLOYER_ID;
	this.EMPLOYER_NAME = EMPLOYER_NAME;
	this.EMPLOY_STATUS = EMPLOY_STATUS;
	this.HIRE_DATE = HIRE_DATE;
	this.HOME_PHONE = HOME_PHONE;
	this.HOME_PHONE_EXTENSION = HOME_PHONE_EXTENSION;
	this.WORK_PHONE = WORK_PHONE;
	this.WORK_PHONE_EXTENSION = WORK_PHONE_EXTENSION;
	this.OCCUPATIONAL_TITLE = OCCUPATIONAL_TITLE;
	this.ADDRESS_1 = ADDRESS_1;
	this.ADDRESS_2 = ADDRESS_2;
	this.CARE_OF = CARE_OF;
	this.CITY = CITY;
	this.COUNTY = COUNTY;
	this.STATE = STATE;
	this.ZIP_CODE_1 = ZIP_CODE_1;
	this.ZIP_CODE_2 = ZIP_CODE_2;
	this.COUNTRY = COUNTRY;
	this.ENROLL_REASON = ENROLL_REASON;
	this.ENR_START_DATE = ENR_START_DATE;
	this.SIGNATURE_DATE = SIGNATURE_DATE;
	this.TERM_REASON = TERM_EFF_DATE;
	this.TERM_EFF_DATE = TERM_EFF_DATE;
	this.COBRA_MONTHS = COBRA_MONTHS;
	this.COBRA_EFF_DATE = COBRA_EFF_DATE;
	this.CUR_ELIGIBILITY = CUR_ELIGIBILITY;
	this.CUR_DUES_AMT = CUR_DUES_AMT;
	this.CUR_COVERAGE_LEVEL_CODE = CUR_COVERAGE_LEVEL_CODE;
	this.LANGUAGE_SPOKEN = LANGUAGE_SPOKEN;
	this.LANGUAGE_WRITTEN = LANGUAGE_WRITTEN;
	this.ETHNICITY = ETHNICITY;
	this.EMPR_MDCR_IN = EMPR_MDCR_IN;
	this.member_Exchange_Id = member_Exchange_Id;
	this.subscriber_Exchange_Id = subscriber_Exchange_Id;
	this.coverage_attribute = coverage_attribute;
	this.tobacco_Use_Indicator = tobacco_Use_Indicator;
	this.tobacco_Use_Indicator_effective_date = tobacco_Use_Indicator_effective_date;
	this.Max_TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE = Max_TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE;
	this.TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_END_DATE = TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_END_DATE;
	this.TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE = TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE;
	this.TAP_COVERAGE_PREMIUM_RATE_EXCHANGE_CSR_AMOUNT = TAP_COVERAGE_PREMIUM_RATE_EXCHANGE_CSR_AMOUNT;
	this.individual_Email_address = individual_Email_address;
    }

    public String getNEDIRecordType() {
	return NEDIRecordType;
    }

    public void setNEDIRecordType(String nEDIRecordType) {
	NEDIRecordType = nEDIRecordType;
    }

    public String getExchangeType() {
	return exchangeType;
    }

    public void setExchangeType(String exchangeType) {
	this.exchangeType = exchangeType;
    }

    public String getBatch_Ref_834() {
	return batch_Ref_834;
    }

    public void setBatch_Ref_834(String batch_Ref_834) {
	this.batch_Ref_834 = batch_Ref_834;
    }

    public String getNEDI_Batch_Generated_Time() {
	return NEDI_Batch_Generated_Time;
    }

    public void setNEDI_Batch_Generated_Time(String nEDI_Batch_Generated_Time) {
	NEDI_Batch_Generated_Time = nEDI_Batch_Generated_Time;
    }

    public String getNEDI_Batch_Processing_Time() {
	return NEDI_Batch_Processing_Time;
    }

    public void setNEDI_Batch_Processing_Time(String nEDI_Batch_Processing_Time) {
	NEDI_Batch_Processing_Time = nEDI_Batch_Processing_Time;
    }

    public String getNEDITOMAG_Record_Length() {
	return NEDITOMAG_Record_Length;
    }

    public void setNEDITOMAG_Record_Length(String nEDITOMAG_Record_Length) {
	NEDITOMAG_Record_Length = nEDITOMAG_Record_Length;
    }

    public String getKAISER_REGION() {
	return KAISER_REGION;
    }

    public void setKAISER_REGION(String kAISER_REGION) {
	KAISER_REGION = kAISER_REGION;
    }

    public String getRECORD_TYPE() {
	return RECORD_TYPE;
    }

    public void setRECORD_TYPE(String rECORD_TYPE) {
	RECORD_TYPE = rECORD_TYPE;
    }

    public String getRMS_GROUP_NO() {
	return RMS_GROUP_NO;
    }

    public void setRMS_GROUP_NO(String rMS_GROUP_NO) {
	RMS_GROUP_NO = rMS_GROUP_NO;
    }

    public String getRMS_SUBGROUP() {
	return RMS_SUBGROUP;
    }

    public void setRMS_SUBGROUP(String rMS_SUBGROUP) {
	RMS_SUBGROUP = rMS_SUBGROUP;
    }

    public String getRMS_BILLGROUP() {
	return RMS_BILLGROUP;
    }

    public void setRMS_BILLGROUP(String rMS_BILLGROUP) {
	RMS_BILLGROUP = rMS_BILLGROUP;
    }

    public String getEXCHANGE_QHP_ID() {
	return EXCHANGE_QHP_ID;
    }

    public void setEXCHANGE_QHP_ID(String eXCHANGE_QHP_ID) {
	EXCHANGE_QHP_ID = eXCHANGE_QHP_ID;
    }

    public String getCONTRACT() {
	return CONTRACT;
    }

    public void setCONTRACT(String cONTRACT) {
	CONTRACT = cONTRACT;
    }

    public String getCONTRACT_OPTION1() {
	return CONTRACT_OPTION1;
    }

    public void setCONTRACT_OPTION1(String cONTRACT_OPTION1) {
	CONTRACT_OPTION1 = cONTRACT_OPTION1;
    }

    public String getCONTRACT_OPTION2() {
	return CONTRACT_OPTION2;
    }

    public void setCONTRACT_OPTION2(String cONTRACT_OPTION2) {
	CONTRACT_OPTION2 = cONTRACT_OPTION2;
    }

    public String getCONTRACT_OPTION3() {
	return CONTRACT_OPTION3;
    }

    public void setCONTRACT_OPTION3(String cONTRACT_OPTION3) {
	CONTRACT_OPTION3 = cONTRACT_OPTION3;
    }

    public String getACTIVITY_DATE() {
	return ACTIVITY_DATE;
    }

    public void setACTIVITY_DATE(String aCTIVITY_DATE) {
	ACTIVITY_DATE = aCTIVITY_DATE;
    }

    public String getMAINT_TYPE_CODE_Health_Coverage_834() {
	return MAINT_TYPE_CODE_Health_Coverage_834;
    }

    public void setMAINT_TYPE_CODE_Health_Coverage_834(String mAINT_TYPE_CODE_Health_Coverage_834) {
	MAINT_TYPE_CODE_Health_Coverage_834 = mAINT_TYPE_CODE_Health_Coverage_834;
    }

    public String getTRANS_TYPE_3() {
	return TRANS_TYPE_3;
    }

    public void setTRANS_TYPE_3(String tRANS_TYPE_3) {
	TRANS_TYPE_3 = tRANS_TYPE_3;
    }

    public String getRECORD_CODE_3() {
	return RECORD_CODE_3;
    }

    public void setRECORD_CODE_3(String rECORD_CODE_3) {
	RECORD_CODE_3 = rECORD_CODE_3;
    }

    public String getMRN_PREFIX_3() {
	return MRN_PREFIX_3;
    }

    public void setMRN_PREFIX_3(String mRN_PREFIX_3) {
	MRN_PREFIX_3 = mRN_PREFIX_3;
    }

    public String getMRN_HRN() {
	return MRN_HRN;
    }

    public void setMRN_HRN(String mRN_HRN) {
	MRN_HRN = mRN_HRN;
    }

    public String getFAN_PREFIX() {
	return FAN_PREFIX;
    }

    public String getFAN() {
	return FAN;
    }

    public String getMEDI_CAL_NBR() {
	return MEDI_CAL_NBR;
    }

    public String getLAST_NAME() {
	return LAST_NAME;
    }

    public String getFIRST_NAME() {
	return FIRST_NAME;
    }

    public String getMIDDLE_NAME() {
	return MIDDLE_NAME;
    }

    public String getPREFIX_NAME() {
	return PREFIX_NAME;
    }

    public String getTITLE_NAME() {
	return TITLE_NAME;
    }

    public String getDISPLAY_NAME() {
	return DISPLAY_NAME;
    }

    public String getACCOUNT_ROLE() {
	return ACCOUNT_ROLE;
    }

    public String getSUBSCRIBERLESS_FLAG() {
	return SUBSCRIBERLESS_FLAG;
    }

    public String getBIRTH_DATE() {
	return BIRTH_DATE;
    }

    public String getMARITAL_STATUS() {
	return MARITAL_STATUS;
    }

    public String getGENDER_CODE() {
	return GENDER_CODE;
    }

    public String getMEDICARE_STATUS() {
	return MEDICARE_STATUS;
    }

    public String getSPECIAL_DEP_STATUS_Student() {
	return SPECIAL_DEP_STATUS_Student;
    }

    public String getSPECIAL_DEP_STATUS_Handicap() {
	return SPECIAL_DEP_STATUS_Handicap;
    }

    public String getNBR_IN_FAMILY() {
	return NBR_IN_FAMILY;
    }

    public String getSUB_SSN() {
	return SUB_SSN;
    }

    public String getMEM_SSN() {
	return MEM_SSN;
    }

    public String getSUB_EMPL_ID_SUP() {
	return SUB_EMPL_ID_SUP;
    }

    public String getSUB_EMPL_ID() {
	return SUB_EMPL_ID;
    }

    public String getSUPPLEMENTAL_ID() {
	return SUPPLEMENTAL_ID;
    }

    public String getFS_EMPLOYER_ID() {
	return FS_EMPLOYER_ID;
    }

    public String getEMPLOYER_NAME() {
	return EMPLOYER_NAME;
    }

    public String getEMPLOY_STATUS() {
	return EMPLOY_STATUS;
    }

    public String getHIRE_DATE() {
	return HIRE_DATE;
    }

    public String getHOME_PHONE() {
	return HOME_PHONE;
    }

    public String getHOME_PHONE_EXTENSION() {
	return HOME_PHONE_EXTENSION;
    }

    public String getWORK_PHONE() {
	return WORK_PHONE;
    }

    public String getWORK_PHONE_EXTENSION() {
	return WORK_PHONE_EXTENSION;
    }

    public String getOCCUPATIONAL_TITLE() {
	return OCCUPATIONAL_TITLE;
    }

    public String getADDRESS_1() {
	return ADDRESS_1;
    }

    public String getADDRESS_2() {
	return ADDRESS_2;
    }

    public String getCARE_OF() {
	return CARE_OF;
    }

    public String getCITY() {
	return CITY;
    }

    public String getCOUNTY() {
	return COUNTY;
    }

    public String getSTATE() {
	return STATE;
    }

    public String getZIP_CODE_1() {
	return ZIP_CODE_1;
    }

    public String getZIP_CODE_2() {
	return ZIP_CODE_2;
    }

    public String getCOUNTRY() {
	return COUNTRY;
    }

    public String getENROLL_REASON() {
	return ENROLL_REASON;
    }

    public String getENR_START_DATE() {
	return ENR_START_DATE;
    }

    public String getSIGNATURE_DATE() {
	return SIGNATURE_DATE;
    }

    public String getTERM_REASON() {
	return TERM_REASON;
    }

    public String getTERM_EFF_DATE() {
	return TERM_EFF_DATE;
    }

    public String getCOBRA_MONTHS() {
	return COBRA_MONTHS;
    }

    public String getCOBRA_EFF_DATE() {
	return COBRA_EFF_DATE;
    }

    public String getCUR_ELIGIBILITY() {
	return CUR_ELIGIBILITY;
    }

    public String getCUR_DUES_AMT() {
	return CUR_DUES_AMT;
    }

    public String getCUR_COVERAGE_LEVEL_CODE() {
	return CUR_COVERAGE_LEVEL_CODE;
    }

    public String getLANGUAGE_SPOKEN() {
	return LANGUAGE_SPOKEN;
    }

    public String getLANGUAGE_WRITTEN() {
	return LANGUAGE_WRITTEN;
    }

    public String getETHNICITY() {
	return ETHNICITY;
    }

    public String getEMPR_MDCR_IN() {
	return EMPR_MDCR_IN;
    }

    public String setmember_Exchange_Id() {
	return member_Exchange_Id;
    }

    public String getmember_Exchange_Id() {
	return member_Exchange_Id;
    }

    public String setsubscriber_Exchange_Id() {
	return subscriber_Exchange_Id;
    }

    public String getsubscriber_Exchange_Id() {
	return subscriber_Exchange_Id;
    }

    @Override
    public String toString() {
	return "BatchItems [NEDIRecordType=" + NEDIRecordType + ", exchangeType=" + exchangeType + ", batch_Ref_834="
		+ batch_Ref_834 + ", " + "NEDI_Batch_Generated_Time=" + NEDI_Batch_Generated_Time
		+ ", NEDI_Batch_Processing_Time=" + NEDI_Batch_Processing_Time + ", " + "NEDITOMAG_Record_Length="
		+ NEDITOMAG_Record_Length + ", KAISER_REGION=" + KAISER_REGION + ", RECORD_TYPE=" + RECORD_TYPE + ", "
		+ "RMS_GROUP_NO=" + RMS_GROUP_NO + ", RMS_SUBGROUP=" + RMS_SUBGROUP + ", RMS_BILLGROUP=" + RMS_BILLGROUP
		+ ", EXCHANGE_QHP_ID=" + EXCHANGE_QHP_ID + "," + " CONTRACT=" + CONTRACT + ", CONTRACT_OPTION1="
		+ CONTRACT_OPTION1 + ", CONTRACT_OPTION2=" + CONTRACT_OPTION2 + ", CONTRACT_OPTION3=" + CONTRACT_OPTION3
		+ ", " + "ACTIVITY_DATE=" + ACTIVITY_DATE + ", MAINT_TYPE_CODE_Health_Coverage_834="
		+ MAINT_TYPE_CODE_Health_Coverage_834 + ", TRANS_TYPE_3=" + TRANS_TYPE_3 + "," + " RECORD_CODE_3="
		+ RECORD_CODE_3 + ", MRN_PREFIX_3=" + MRN_PREFIX_3 + ", MRN_HRN=" + MRN_HRN + ", FAN_PREFIX = "
		+ FAN_PREFIX + " , FAN = " + FAN + " , " + "MEDI_CAL_NBR = " + MEDI_CAL_NBR + " , LAST_NAME = "
		+ LAST_NAME + " , FIRST_NAME = " + FIRST_NAME + " , MIDDLE_NAME = " + MIDDLE_NAME + " , "
		+ "PREFIX_NAME = " + PREFIX_NAME + " , TITLE_NAME = " + TITLE_NAME + " , DISPLAY_NAME = " + DISPLAY_NAME
		+ " , ACCOUNT_ROLE = " + ACCOUNT_ROLE + " ," + "SUBSCRIBERLESS_FLAG = " + SUBSCRIBERLESS_FLAG
		+ " , BIRTH_DATE = " + BIRTH_DATE + " , MARITAL_STATUS = " + MARITAL_STATUS + " , GENDER_CODE = "
		+ GENDER_CODE + " ," + "MEDICARE_STATUS = " + MEDICARE_STATUS + " , SPECIAL_DEP_STATUS_Student = "
		+ SPECIAL_DEP_STATUS_Student + " , SPECIAL_DEP_STATUS_Handicap = " + SPECIAL_DEP_STATUS_Handicap + " ,"
		+ "NBR_IN_FAMILY = " + NBR_IN_FAMILY + " , SUB_SSN = " + SUB_SSN + " , MEM_SSN = " + MEM_SSN
		+ " , SUB_EMPL_ID_SUP = " + SUB_EMPL_ID_SUP + " , SUB_EMPL_ID = " + SUB_EMPL_ID + " ,"
		+ "SUPPLEMENTAL_ID = " + SUPPLEMENTAL_ID + " , FS_EMPLOYER_ID = " + FS_EMPLOYER_ID
		+ " , EMPLOYER_NAME = " + EMPLOYER_NAME + " , EMPLOY_STATUS = " + EMPLOY_STATUS + " ," + "HIRE_DATE = "
		+ HIRE_DATE + " , HOME_PHONE = " + HOME_PHONE + " , HOME_PHONE_EXTENSION = " + HOME_PHONE_EXTENSION
		+ " , WORK_PHONE = " + WORK_PHONE + " ," + "WORK_PHONE_EXTENSION = " + WORK_PHONE_EXTENSION
		+ " , OCCUPATIONAL_TITLE = " + OCCUPATIONAL_TITLE + " , ADDRESS_1 = " + ADDRESS_1 + " , ADDRESS_2 = "
		+ ADDRESS_2 + " ," + "CARE_OF = " + CARE_OF + " , CITY = " + CITY + " , COUNTY = " + COUNTY
		+ " , STATE = " + STATE + " , ZIP_CODE_1 = " + ZIP_CODE_1 + " , ZIP_CODE_2 = " + ZIP_CODE_2 + " , "
		+ "COUNTRY = " + COUNTRY + " , ENROLL_REASON = " + ENROLL_REASON + " , ENR_START_DATE = "
		+ ENR_START_DATE + " , SIGNATURE_DATE = " + SIGNATURE_DATE + " ," + "TERM_REASON = " + TERM_REASON
		+ " , TERM_EFF_DATE = " + TERM_EFF_DATE + " , COBRA_MONTHS = " + COBRA_MONTHS + " , COBRA_EFF_DATE = "
		+ COBRA_EFF_DATE + " ," + "CUR_ELIGIBILITY = " + CUR_ELIGIBILITY + " , CUR_DUES_AMT = " + CUR_DUES_AMT
		+ " , CUR_COVERAGE_LEVEL_CODE = " + CUR_COVERAGE_LEVEL_CODE + " ," + "LANGUAGE_SPOKEN = "
		+ LANGUAGE_SPOKEN + " , LANGUAGE_WRITTEN = " + LANGUAGE_WRITTEN + " , ETHNICITY = " + ETHNICITY
		+ " , EMPR_MDCR_IN = " + EMPR_MDCR_IN + ", member_Exchange_Id = " + member_Exchange_Id
		+ ", subscriber_Exchange_Id = \" + subscriber_Exchange_Id +\"" + " coverage_attribute = "
		+ coverage_attribute + ", tobacco_Use_Indicator = " + tobacco_Use_Indicator
		+ " , tobacco_Use_Indicator_effective_date =  " + tobacco_Use_Indicator_effective_date
		+ ", subsidy_Indicator = " + subsidy_Indicator + ""
		+ " TAP_COVERAGE_PREMIUM_RATE_EXCHANGE_CSR_AMOUNT = " + TAP_COVERAGE_PREMIUM_RATE_EXCHANGE_CSR_AMOUNT
		+ ", "
		+ "subsidy_Indicator_effective_date = \" + subsidy_Indicator_effective_date +\", Max_TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE = "
		+ Max_TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE + ","
		+ "TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_END_DATE = " + TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_END_DATE
		+ ", " + " TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE = "
		+ TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE + ", individual_Email_address = "
		+ individual_Email_address + "]";
    }

    public String getCoverage_attribute() {
	return coverage_attribute;
    }

    public void setCoverage_attribute(String coverage_attribute) {
	this.coverage_attribute = coverage_attribute;
    }

    public String getTobacco_Use_Indicator() {
	return tobacco_Use_Indicator;
    }

    public void setTobacco_Use_Indicator(String tobacco_Use_Indicator) {
	this.tobacco_Use_Indicator = tobacco_Use_Indicator;
    }

    public String getTobacco_Use_Indicator_effective_date() {
	return tobacco_Use_Indicator_effective_date;
    }

    public void setTobacco_Use_Indicator_effective_date(String tobacco_Use_Indicator_effective_date) {
	this.tobacco_Use_Indicator_effective_date = tobacco_Use_Indicator_effective_date;
    }

    public String getSubsidy_Indicator() {
	return subsidy_Indicator;
    }

    public void setSubsidy_Indicator(String subsidy_Indicator) {
	this.subsidy_Indicator = subsidy_Indicator;
    }

    public String getTAP_COVERAGE_PREMIUM_RATE_EXCHANGE_CSR_AMOUNT() {
	return TAP_COVERAGE_PREMIUM_RATE_EXCHANGE_CSR_AMOUNT;
    }

    public void setTAP_COVERAGE_PREMIUM_RATE_EXCHANGE_CSR_AMOUNT(String tAP_COVERAGE_PREMIUM_RATE_EXCHANGE_CSR_AMOUNT) {
	TAP_COVERAGE_PREMIUM_RATE_EXCHANGE_CSR_AMOUNT = tAP_COVERAGE_PREMIUM_RATE_EXCHANGE_CSR_AMOUNT;
    }

    public String getSubsidy_Indicator_effective_date() {
	return subsidy_Indicator_effective_date;
    }

    public void setSubsidy_Indicator_effective_date(String subsidy_Indicator_effective_date) {
	this.subsidy_Indicator_effective_date = subsidy_Indicator_effective_date;
    }

    public String getMax_TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE() {
	return Max_TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE;
    }

    public void setMax_TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE(
	    String max_TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE) {
	Max_TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE = max_TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE;
    }

    public String getTAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_END_DATE() {
	return TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_END_DATE;
    }

    public void setTAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_END_DATE(String tAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_END_DATE) {
	TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_END_DATE = tAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_END_DATE;
    }

    public String getTAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE() {
	return TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE;
    }

    public void setTAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE(
	    String tAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE) {
	TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE = tAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE;
    }

    public String getIndividual_Email_address() {
	return individual_Email_address;
    }

    public void setIndividual_Email_address(String individual_Email_address) {
	this.individual_Email_address = individual_Email_address;
    }

}
