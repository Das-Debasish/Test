package org.kp.ene.membershipenrollment;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;

import org.json.JSONException;
import org.kp.ene.membershipenrollment.dao.ExtractTestAutomationDaoImpl;
import org.kp.ene.membershipenrollment.dao.StagerQueryFieldsDTO;
import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.databind.ObjectMapper;

public class CompareStageQueryFieldsToDatahub {

    @Autowired
    static ExtractTestAutomationDaoImpl daoImpl;

    EnrollmentFieldsDatahub datahub;

    StagerQueryFieldsDTO stgDTO;

    public CompareStageQueryFieldsToDatahub() {
    }

    public static String getEnrollmentFromDatahub(String fileName) throws IOException, JSONException {
	EnrollmentFieldsDatahub datahubObj = FlatFileToDTOUtil.readInboundFileAndGetEnrollmentDTO(fileName).get(0);
	assertNotNull(datahubObj, "Datahub Object should not be null");

	ObjectMapper Obj = new ObjectMapper();
	String jsonStr = null;
	try {
	    jsonStr = Obj.writeValueAsString(datahubObj);
	} catch (IOException e) {
	    e.printStackTrace();
	}
	return jsonStr;
    }

    public static String getDTO() {
	// TODO replace this query for retrieving actual data using MRN
	StagerQueryFieldsDTO stagingDTO = new StagerQueryFieldsDTO("SCA", "191", "123456789", "SDGR", "ABCDE1234",
		"Self", "ASDFGHT3462754", "ASDFGHT3462754", "1234056789", "Ponnaganta", "Hari", "Priya", null,
		"20200407", "Married", "Female", null, null, null, "9135929402", "1", "6731 W 156th St", "Apt-1009",
		"Overland Park", "Johnson", "KS", "66223", "USA", "Emp", "20200407", "Not in", "20200407", "20200407",
		"EN", "EN", "A", "ASDFGHT3462754", "ASDFGHT3462754", null, "20200407", "kpmkl.ansjnd@kp.org", "234",
		"20200407", "20200407", null, null, "20200407");

	assertNotNull(stagingDTO, "stageDTO should not be null");

	ObjectMapper Obj = new ObjectMapper();
	String jsonStr = null;
	try {
	    jsonStr = Obj.writeValueAsString(stagingDTO);
	} catch (IOException e) {
	    e.printStackTrace();
	}
	return jsonStr;
    }

//TODO move these assertions to Karate
    /**
     * Validate the following field in the Data hub Nedi Record Type from the Data
     * hub whose Tgt_Start_pos = 1 & Tgt_Field_Lentgh = 1 And Refer to logic below
     * If TAP_COVERAGE REGION_CODE = "NCA" Then "NCR" Else if TAP_COVERAGE
     * REGION_CODE = "SCA" Then "SCR" Else do not write record. Nedi Record Type is
     * verified and the Region is set successfully according to the logic given in
     * the Mapping documents.
     * 
     * @param datahub
     * @param stgDTO
     */
    public static void validate1(EnrollmentFieldsDatahub datahub, StagerQueryFieldsDTO stgDTO) {
	if (datahub.getNEDIRecordType() != null) {
	    // TODO check later
	    if ("NCA".equals(stgDTO.getTc_region_code())) {
		assertEquals("N", datahub.getNEDIRecordType());
	    } else if ("SCA".equals(stgDTO.getTc_region_code())) {
		assertEquals("S", datahub.getNEDIRecordType());
	    } else {
		assertEquals("", datahub.getKAISER_REGION());
	    }
	}
    }

    /**
     * Validate the following field in the Data hub Exchange Type(INDV or SHOP) from
     * the Data hub Whose Tgt_Start_pos = 2 & Tgt_Field_length =4 And Refer to logic
     * below Set to 'FI' and Also Validate the Kaiser Region from the Data hub Whose
     * Tgt_Start_pos = 71 & Tgt_Field_length = 3
     * 
     * @param datahub
     * @param stgDTO
     */
    public static void validate4(EnrollmentFieldsDatahub datahub, StagerQueryFieldsDTO stgDTO) {
	String type = "FI";
	String exchangeType = datahub.getExchangeType();

	if (exchangeType != null) {
	    boolean match = type.equals("FI") || type.equals("24");
	    assertTrue(match, "Exchange type not as expected");
	}

	if (datahub.getKAISER_REGION() != null) {
	    assertEquals(stgDTO.getTpm_region_code(), datahub.getKAISER_REGION());
	}
    }

    /**
     * Validate the following field in the Data hub the Record_Type from the Data
     * hub Whose Tgt_Start_pos = 74 & Tgt_Field_length = 1 And Refer to the logic
     * below 1 if Transaction File; 2 if Full File The Record Type is Verified and
     * the Record Type is Set according to the logic
     * 
     * @param datahub
     * @param stgDTO
     */
    public static void validate5(EnrollmentFieldsDatahub datahub, StagerQueryFieldsDTO stgDTO) {
	String recordType = datahub.getRECORD_TYPE();
	if (recordType != null) {
	    boolean match = recordType.equals("1") || recordType.equals("2");
	    assertTrue(match, "Record type not as expected");
	}
    }

    /**
     * Validate the following field in the Data hub Rms_Group_no Whose Tgt_Start_pos
     * = 75 & Tgt_Field_length = 9 and Rms_subgroups Whose Tgt_Start_pos = 84 &
     * Tgt_Field_length = 4 from the Data hub The Rms_Group_no and Rms_subgroup is
     * verified Successfully
     * 
     * @param datahub
     * @param stgDTO
     */
    public static void validate6(EnrollmentFieldsDatahub datahub, StagerQueryFieldsDTO stgDTO) {
	assertEquals(stgDTO.getRegional_customer_id(), datahub.getRMS_GROUP_NO());
	assertEquals(stgDTO.getEligibility_subgroup_id(), datahub.getRMS_SUBGROUP());
    }

    /**
     * Validate the following fields in the Data hub Exchange-QHP_ID Whose
     * Tgt_Start_pos = 90 & Tgt_Field_length = 20, Contract Whose Tgt_Start_pos =
     * 110 & Tgt_Field_length = 9 and Contract option 1 Whose Tgt_Start_pos = 119 &
     * Tgt_Field_length = 9 from the data hub.
     * 
     * The Exchange-QHP_ID, Contract field and Contract option 1 is verified
     * Successfully
     * 
     * @param datahub
     * @param stgDTO
     */
    public static void validate7(EnrollmentFieldsDatahub datahub, StagerQueryFieldsDTO stgDTO) {
	// Only found this in transformer
	assertEquals(stgDTO.getContract_id(), datahub.getCONTRACT());
	assertFalse(datahub.getEXCHANGE_QHP_ID().isEmpty());
	assertFalse(datahub.getCONTRACT_OPTION1().isEmpty());
    }

    /**
     * Validate the following fields in the Data hub 3 Record Code from
     * Tgt_Start_pos = 158 & Tgt_Field_length = 1 and Refer to the logic
     * TAP_PERSON_COVERAGE.PERSON_REL_TO_SUBSCRIBER_CODE = "Self" Then "A" Else "D"
     * The 3 Record Code is validated and the required field is set according to the
     * logic.
     * 
     * @param datahub
     * @param stgDTO
     */
    public static void validate8(EnrollmentFieldsDatahub datahub, StagerQueryFieldsDTO stgDTO) {
	if ("Self".equalsIgnoreCase(stgDTO.getPerson_rel_to_subscriber_code())) {
	    assertEquals("A", datahub.getRECORD_CODE_3());
	} else {
	    assertEquals("D", datahub.getRECORD_CODE_3());
	}
    }

    /**
     * Validate the following field in the Data hub 3 MRN prefix having
     * TGT_Start_Pos = 159 & Tgt_Field_Length = 2 and refer to the logic below If
     * TAP_PERSON_MRN exists for TAP_COVERAGE.REGION_CODE Then Map first two chars
     * Else do not populate 3 MRN Prefix is varified and the req field is set
     * according to the logic
     * 
     * @param datahub
     * @param stgDTO
     */
    public static void validate9(EnrollmentFieldsDatahub datahub, StagerQueryFieldsDTO stgDTO) {
	if (stgDTO.getMrn() != null) {
	    assertEquals(stgDTO.getMrn().substring(0, 1), datahub.getMRN_PREFIX_3().trim());
	} else {
	    assertTrue(datahub.getMRN_PREFIX_3().isEmpty());
	}
    }

    /**
     * Validate the following field in the Data hub MRN-HRN Value from the
     * Tgt_Start_pos = 161 & Tgt_Field_length = 10 and Refer to the logic If
     * TAP_PERSON_MRN exists for TAP_COVERAGE.REGION_CODE Then Map last 10 chars
     * Else do not populate MRN-HRN is validated Successfully and the req field is
     * set according to the logic
     * 
     * @param datahub
     * @param stgDTO
     */
    public static void validate10(EnrollmentFieldsDatahub datahub, StagerQueryFieldsDTO stgDTO) {

	if (stgDTO.getMrn() != null) {
	    assertEquals(stgDTO.getMrn().substring(stgDTO.getMrn().length() - 10), datahub.getMRN_HRN());
	} else {
	    assertTrue(datahub.getMRN_HRN().isEmpty());
	}
    }

    /**
     * Validate the following fields in the Data hub FAN Prefix Value from the
     * Tgt_Start_pos = 171 & Tgt_Field_length = 2, MRN-HRN Value from the
     * Tgt_Start_pos = 173 & Tgt_Field_length = 10 and Refer to the logic and Refer
     * to the logic For FAN_Prefix If TAP_PERSON_MRN exists for
     * TAP_COVERAGE.REGION_CODE where TAP_COVERAGE.SUBSCRIBER_ID =
     * TAP_PERSON_MRN.PERSON_ID Then Map first two chars Else do not populate For
     * FAN If TAP_PERSON_MRN exists for TAP_COVERAGE.REGION_CODE where
     * TAP_COVERAGE.SUBSCRIBER_ID = TAP_PERSON_MRN.PERSON_ID Then Map last 10 chars
     * Else do not populate FAN_Prefix and FAN is validated Successfully and the Req
     * field is set according to the logic
     * 
     * @param datahub
     * @param stgDTO
     */
    public static void validate11(EnrollmentFieldsDatahub datahub, StagerQueryFieldsDTO stgDTO) {
	if (stgDTO.getMrn() != null && stgDTO.getSubscriber_id().equals(stgDTO.getPerson_id())) {
	    stgDTO.getMrn().substring(0, 2);
	    assertFalse(datahub.getFAN_PREFIX().isEmpty());
	    assertFalse(datahub.getFAN().isEmpty());
	} else {
	    assertTrue(datahub.getFAN_PREFIX().isEmpty());
	    assertTrue(datahub.getFAN().isEmpty());
	}
    }

    /**
     * Validate the following fields in the Data hub the Address-1 from
     * Tgt_Start_pos = 558 & Tgt_Field_Lentgh = 40, Address-2 from Tgt_Start_pos =
     * 598 & Tgt_Field_Lentgh = 40, City from Tgt_Start_pos = 668 & Tgt_Field_Lentgh
     * = 45, County from Tgt_Start_pos = 713 & Tgt_Field_Lentgh = 45, and State from
     * Tgt_Start_pos = 758 & Tgt_Field_Lentgh = 2 Address-1,Address-2, City, County,
     * State is validated Successfully
     * 
     * @param datahub
     * @param stgDTO
     */
    public static void validate14(EnrollmentFieldsDatahub datahub, StagerQueryFieldsDTO stgDTO) {
	assertEquals(stgDTO.getAddress_line_1(), datahub.getADDRESS_1().trim());
	assertEquals(stgDTO.getAddress_line_2(), datahub.getADDRESS_2().trim());
	assertEquals(stgDTO.getCity(), datahub.getCITY().trim());
	assertEquals(stgDTO.getCounty_code(), datahub.getCOUNTY().trim());
	assertEquals(stgDTO.getState_code(), datahub.getSTATE());
    }

    /**
     * Validate the following fields in the Data hub the Zip-Code 1 from
     * Tgt_Start_pos = 760 & Tgt_Field_Lentgh = 7 Zip-Code 1 Validated successfully.
     * 
     * @param datahub
     * @param stgDTO
     */
    public static void validate15(EnrollmentFieldsDatahub datahub, StagerQueryFieldsDTO stgDTO) {
	assertEquals(stgDTO.getPostal_code().substring(0, 5), datahub.getZIP_CODE_1().trim());
    }

    /**
     * Validate the Data hub Zip-Code 2 from Tgt_Start_pos = 767 & Tgt_Field_Lentgh
     * = 4 and refer the following logic If Country = "USA" and ZipCode length in
     * (9,10) then map last 4 characters Else do not populate Zip Code 2 is
     * validated and Req field is set according to the logic.
     * 
     * @param datahub
     * @param stgDTO
     */
    public static void validate16(EnrollmentFieldsDatahub datahub, StagerQueryFieldsDTO stgDTO) {

	int length = stgDTO.getPostal_code().length();
	if ("USA".equals(datahub.getCOUNTRY()) && length == 9 || length == 10) {
	    assertEquals(datahub.getZIP_CODE_2(), stgDTO.getPostal_code().substring(length - 4));
	} else {
	    assertTrue(datahub.getZIP_CODE_2().isEmpty());
	}
    }

    /**
     * Validate the Country Name from Tgt_Start_pos = 771 & Tgt_Field_Lentgh = 45.
     * select to_value from CROSS_WALK where application_code =
     * 'KPMC_GEOGRAPHIC_APP' and from_value = $COUNTRY_CODE'; May not be provided
     * for all countries. Country name is validated successfully and the req field
     * is set according to the logic
     * 
     * @param datahub
     * @param stgDTO
     */

    public static void validate17(EnrollmentFieldsDatahub datahub, StagerQueryFieldsDTO stgDTO) {
	String countryCode = daoImpl.getToValueFromCrossWalk("COMMON", "KPMC_GEOGRAPHIC_APP",
		"KPMC_COUNTRY_3CHAR_TO_FULL", datahub.getCOUNTRY());
	if (countryCode != null) {
	    assertEquals(stgDTO.getCountry_code(), datahub.getCOUNTRY());
	} else {
	    assertFalse(datahub.getCOUNTRY().isEmpty());
	}
    }

    /**
     * Validate the following fields in the Data hub the Enroll-Reason which is
     * located in the data hub whose Tgt_Start_pos = 816 & Tgt_Field_Lentgh = 12,
     * Signature Date whose Tgt_Start_pos = 836 & Tgt_Field_Lentgh = 8, Term Reason
     * Whose Tgt_Start_pos = 844 & Tgt_Field_Lentgh = 12 the fields like Enroll
     * Reason, Signature date and Term Date is validated successfully
     * 
     * @param datahub
     * @param stgDTO
     */
    public static void validate18(EnrollmentFieldsDatahub datahub, StagerQueryFieldsDTO stgDTO) {
	assertEquals(stgDTO.getPerson_enroll_reason_code(), datahub.getENROLL_REASON().trim());
	assertEquals(stgDTO.getPerson_application_date(), datahub.getSIGNATURE_DATE());
	String reasonCode = daoImpl.getToValueFromCrossWalk("ENRLLMNT_ELIGIBILITY", "FS_ENROLLMENT",
		"PERSON_TERM_REASON_CODE", stgDTO.getPerson_term_reason_code());
	assertEquals(reasonCode, datahub.getTERM_REASON());
	assertEquals(stgDTO.getTpc_effective_end_date(), datahub.getTERM_EFF_DATE());
    }

    /**
     * Validate the following fields in the Data hub the ENR Start Date which is
     * located in the data hub whose Tgt_Start_pos = 828 & Tgt_Field_Lentgh = 8 and
     * The value of the field is set according to the logic below Query
     * Tap_Person_Coverage to determine if member has coverages provided by same
     * employer group in prior periods. Find earliest coverage for same employer
     * group and return that effective_start_date. The Field like ENR Start Date is
     * Validated and set according to the logic
     * 
     * @param datahub
     * @param stgDTO
     */

    public static void validate19(EnrollmentFieldsDatahub datahub, StagerQueryFieldsDTO stgDTO) {
	// TODO
	assertEquals(datahub.getENR_START_DATE(), stgDTO.getTpc_effectivde_start_date());
    }

    /**
     * Validate the following fields in the Data hub the Term EFF date which is
     * located in the data hub whose Tgt_Start_pos = 856 & Tgt_Field_Lentgh = 8 The
     * Field Term EFF Date is validated Successfully
     * 
     * @param datahub
     * @param stgDTO
     */

    public static void validate20(EnrollmentFieldsDatahub datahub, StagerQueryFieldsDTO stgDTO) {
	assertEquals(stgDTO.getTpc_effective_end_date(), datahub.getTERM_EFF_DATE());
    }

    /**
     * Validate the following fields in the Data hub the CUR-Dues-Amt Which is
     * Located in the data hub whose gt_Start_pos = 875 & Tgt_Field_Lentgh = 7 and
     * set the field according to the logic below Set to 0 The CUR Dues Amt is
     * Validated from the target position successfully and the field is set to '0'
     * 
     * @param datahub
     * @param stgDTO
     */

    public static void validate21(EnrollmentFieldsDatahub datahub, StagerQueryFieldsDTO stgDTO) {
	assertEquals("0", datahub.getCUR_DUES_AMT().trim());
    }

    /**
     * Validate the following fields in the Data hub the Language-Spoken,
     * Language-Written,Ethnicity from the location in the data hub having
     * Tgt_Start_pos = 887 & Tgt_Field_Lentgh = 2, Tgt_Start_pos = 889 &
     * Tgt_Field_Lentgh = 2, Tgt_Start_pos = 891 & Tgt_Field_Lentgh = 2 respectively
     * The given field is validated from the located postion successfully
     * 
     * @param datahub
     * @param stgDTO
     */

    /*
     * public static void validate22(EnrollmentFieldsDatahub datahub,
     * StagerQueryFieldsDTO stgDTO) { if (datahub.getLANGUAGE_SPOKEN() != null) {
     * String lang = daoImpl.getToValueFromCrossWalk("ENRLLMNT_ELIGIBILITY",
     * "FS_ENROLLMENT", "KPMC_TO_FS_LANGUAGE", stgDTO.getLanguage_type_code());
     * 
     * assertEquals(lang, datahub.getLANGUAGE_SPOKEN()); assertEquals(lang,
     * datahub.getLANGUAGE_WRITTEN()); } if (datahub.getETHNICITY() != null) {
     * assertEquals(stgDTO.getEthnicity_code(), datahub.getETHNICITY()); } }
     */

    // Test Case Scenario - 5

    /**
     * Validate the Following field from the Data Hub having different target
     * positions as follows Member Exchange id from Tgt_Start_pos = 894 &
     * Tgt_Field_Lentgh = 50 Subscriber Exchange Id From Tgt_Start_pos = 944 &
     * Tgt_Field_Lentgh = 50 The Given Field is validated successfully from the
     * given positions
     * 
     * @param datahub
     * @param stgDTO
     */

    public static void validate24(EnrollmentFieldsDatahub datahub, StagerQueryFieldsDTO stgDTO) {
	if (datahub.getmember_Exchange_Id() != null) {
	    assertEquals(stgDTO.getGroup_member_id(), datahub.getmember_Exchange_Id().trim());
	}
	if (datahub.getsubscriber_Exchange_Id() != null) {
	    assertEquals(stgDTO.getGroup_subscriber_id(), datahub.getsubscriber_Exchange_Id().trim());
	}
    }

    /**
     * Validate the Following field from the Data Hub having different target
     * positions and Refer to the logic as follows Tobacco Use Indicator from
     * Tgt_Start_pos = 994 & Tgt_Field_Lentgh = 1 and logic is When coverage
     * attribute = Tobacco Usage Indicator , Tobacco Use Indicator effective date
     * from Tgt_Start_pos = 995 & Tgt_Field_Lentgh = 8 and logic is When coverage
     * attribute = Tobacco Usage Indicator The Given Field is validated successfully
     * from the given positions and the logic is referred while validating
     * 
     * @param datahub
     * @param stgDTO
     */

    public static void validate25(EnrollmentFieldsDatahub datahub, StagerQueryFieldsDTO stgDTO) {

	if ("Tobacco Usag".equalsIgnoreCase(stgDTO.getPerson_coverage_attribute())) {
	    assertEquals("Y", datahub.getTobacco_Use_Indicator());
	} else {
	    assertEquals("N", datahub.getTobacco_Use_Indicator());
	}

	// this is in transformer logic but in database there is no Tobacco Usage
	// Indicator"
	if ("Tobacco Usage Indicator".equalsIgnoreCase(stgDTO.getPerson_coverage_attribute())) {
	    assertEquals(stgDTO.getPca_eff_start_date(), datahub.getTobacco_Use_Indicator_effective_date());
	} else {
	    assertTrue(datahub.getTobacco_Use_Indicator_effective_date().trim().isEmpty());
	}
    }

    /**
     * Validate the Following field from the Data Hub having different target
     * positions and Refer to the logic as follows Subsidy Indicator from
     * Tgt_Start_pos = 1003 & Tgt_Field_Lentgh = 1 and the logic is Set to Y if
     * TAP_COVERAGE_PREMIUM_RATE.EXCHANGE_CSR_AMOUNT not Zero The Given Field is
     * validated successfully from the given positions and the Required fields is
     * set according to the logic
     * 
     * @param datahub
     * @param stgDTO
     */

    public static void validate26(EnrollmentFieldsDatahub datahub, StagerQueryFieldsDTO stgDTO) {

	if (datahub.getSubsidy_Indicator() != null) {
	    if (stgDTO.getExchange_csr_amount() != null) {
		assertEquals("Y", datahub.getSubsidy_Indicator());
	    } else {
		assertEquals("N", datahub.getSubsidy_Indicator());
	    }
	}
    }

    /**
     * Validate the Following field from the Data Hub having different target
     * positions and Refer to the logic as follows Subsidy Indicator effective date
     * from Tgt_Start_pos = 1004 & Tgt_Field_Lentgh = 8 and the logic is Max
     * TAP_COVERAGE_PREMIUM_RATE.EFFECTIVE_START_DATE when
     * TAP_COVERAGE_PREMIUM_RATE.EFFECTIVE_END_DATE > Effective Coverage Date and
     * TAP_COVERAGE_PREMIUM_RATE.EFFECTIVE_START_DATE < Effective Coverage End Date
     * and TAP_COVERAGE_PREMIUM_RATE.EXCHANGE_CSR_AMOUNT not Zero The Given Field is
     * validated successfully from the given positions and the Required fiels is set
     * according to the logic
     * 
     * @param datahub
     * @param stgDTO
     */

    public static void validate27(EnrollmentFieldsDatahub datahub, StagerQueryFieldsDTO stgDTO) {

	// if(datahub.getTAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE() > datahub.get)
    }

    /**
     * Validate the Following field from the Data Hub having different target
     * positions as follows Individual Email address from Tgt_Start_pos = 1057 &
     * Tgt_Field_Lentgh = 80 The Given Field is validated successfully from the
     * given positions
     * 
     * @param datahub
     * @param stgDTO
     */

    public static void validate28(EnrollmentFieldsDatahub datahub, StagerQueryFieldsDTO stgDTO) {

	assertEquals(stgDTO.getEmail_address(), datahub.getIndividual_Email_address().trim());
    }

}
