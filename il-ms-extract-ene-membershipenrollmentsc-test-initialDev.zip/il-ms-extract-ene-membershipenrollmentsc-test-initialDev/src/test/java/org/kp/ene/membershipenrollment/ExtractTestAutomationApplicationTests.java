package org.kp.ene.membershipenrollment;

import org.kp.kpmc.extract.automation.ExtractTestAutomationApplication;

import com.intuit.karate.junit5.Karate;

public class ExtractTestAutomationApplicationTests {

    @Karate.Test
    Karate testUsers() {
	String inputFileName = "mebership_enrollment_sc_20210713100051.txt";
	ExtractTestAutomationApplication.main(new String[] { inputFileName });
	System.out.println("System varialbe: " + System.getProperty("env"));
	if (System.getProperty("env") == null)
	    System.setProperty("karate.env", "DIT");
	else
	    System.setProperty("karate.env", System.getProperty("env"));

	System.out.println("Start Test Cases===================>");
	return Karate.run("interface127Tests").relativeTo(getClass());
	// return null;
    }
}
