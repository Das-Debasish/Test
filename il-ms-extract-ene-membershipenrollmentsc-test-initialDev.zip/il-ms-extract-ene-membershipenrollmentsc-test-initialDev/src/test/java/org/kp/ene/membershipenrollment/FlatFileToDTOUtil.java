package org.kp.ene.membershipenrollment;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;
import org.kp.ene.membershipenrollment.dao.ContextLoaderUtil;
import org.kp.ene.membershipenrollment.dao.ExtractTestAutomationDaoImpl;
import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


public class FlatFileToDTOUtil {

    @Autowired
    static ExtractTestAutomationDaoImpl daoImpl;

    public static List<JSONObject> readTargetOuputFields(String fileName)
	    throws IOException, JSONException {
	List<JSONObject> jsonObjectList = new ArrayList<JSONObject>();
	InputStream is = ContextLoaderUtil.getResourceAsStream(fileName, FlatFileToDTOUtil.class);
	String line;
	try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
	    // read line by line
	    while ((line = br.readLine()) != null) {
		jsonObjectList.add(batchItemScanner(line));
	    }
	}
	return jsonObjectList;
    }

    public static JSONObject batchItemScanner(String line) throws JsonProcessingException, JSONException {
	String NEDIRecordType = line.substring(0, 1);
	String exchangeType = line.substring(1, 5);
	String batch_Ref_834 = line.substring(5, 25);
	String NEDI_Batch_Generated_Time = line.substring(25, 45);
	String NEDI_Batch_Processing_Time = line.substring(45, 65);
	String NEDITOMAG_Record_Length = line.substring(65, 70);
	String KAISER_REGION = line.substring(70, 73);
	String RECORD_TYPE = line.substring(73, 74);
	String RMS_GROUP_NO = line.substring(74, 83);
	String RMS_SUBGROUP = line.substring(83, 87);
	String RMS_BILLGROUP = line.substring(87, 89);
	String EXCHANGE_QHP_ID = line.substring(89, 109);
	String CONTRACT = line.substring(109, 118);
	String CONTRACT_OPTION1 = line.substring(118, 127);
	String CONTRACT_OPTION2 = line.substring(127, 136);
	String CONTRACT_OPTION3 = line.substring(136, 145);
	String ACTIVITY_DATE = line.substring(145, 153);
	String MAINT_TYPE_CODE_Health_Coverage_834 = line.substring(153, 156);
	String TRANS_TYPE_3 = line.substring(156, 157);
	String RECORD_CODE_3 = line.substring(157, 158);
	String MRN_PREFIX_3 = line.substring(158, 160);
	String MRN_HRN = line.substring(160, 170);
	String FAN_PREFIX = line.substring(170, 172);
	String FAN = line.substring(172, 182);
	String MEDI_CAL_NBR = line.substring(182, 196);
	String LAST_NAME = line.substring(196, 221);
	String FIRST_NAME = line.substring(221, 246);
	String MIDDLE_NAME = line.substring(246, 271);
	String PREFIX_NAME = line.substring(271, 283);
	String TITLE_NAME = line.substring(283, 295);
	String DISPLAY_NAME = line.substring(295, 328);
	String ACCOUNT_ROLE = line.substring(328, 340);
	String SUBSCRIBERLESS_FLAG = line.substring(340, 341);
	String BIRTH_DATE = line.substring(341, 349);
	String MARITAL_STATUS = line.substring(349, 361);
	String GENDER_CODE = line.substring(361, 368);
	String MEDICARE_STATUS = line.substring(368, 369);
	String SPECIAL_DEP_STATUS_Student = line.substring(369, 370);
	String SPECIAL_DEP_STATUS_Handicap = line.substring(370, 371);
	String NBR_IN_FAMILY = line.substring(371, 373);
	String SUB_SSN = line.substring(373, 382);
	String MEM_SSN = line.substring(382, 391);
	String SUB_EMPL_ID_SUP = line.substring(391, 393);
	String SUB_EMPL_ID = line.substring(393, 402);
	String SUPPLEMENTAL_ID = line.substring(402, 418);
	String FS_EMPLOYER_ID = line.substring(418, 422);
	String EMPLOYER_NAME = line.substring(422, 482);
	String EMPLOY_STATUS = line.substring(482, 489);
	String HIRE_DATE = line.substring(489, 497);
	String HOME_PHONE = line.substring(497, 507);
	String HOME_PHONE_EXTENSION = line.substring(507, 512);
	String WORK_PHONE = line.substring(512, 522);
	String WORK_PHONE_EXTENSION = line.substring(522, 527);
	String OCCUPATIONAL_TITLE = line.substring(527, 557);
	String ADDRESS_1 = line.substring(557, 597);
	String ADDRESS_2 = line.substring(597, 637);
	String CARE_OF = line.substring(637, 667);
	String CITY = line.substring(667, 712);
	String COUNTY = line.substring(712, 757);
	String STATE = line.substring(757, 759);
	String ZIP_CODE_1 = line.substring(759, 766);
	String ZIP_CODE_2 = line.substring(766, 770);
	String COUNTRY = line.substring(770, 815);
	String ENROLL_REASON = line.substring(815, 827);
	String ENR_START_DATE = line.substring(827, 835);
	String SIGNATURE_DATE = line.substring(835, 843);
	String TERM_REASON = line.substring(843, 855);
	String TERM_EFF_DATE = line.substring(855, 863);
	String COBRA_MONTHS = line.substring(863, 865);
	String COBRA_EFF_DATE = line.substring(865, 873);
	String CUR_ELIGIBILITY = line.substring(873, 874);
	String CUR_DUES_AMT = line.substring(874, 881);
	String CUR_COVERAGE_LEVEL_CODE = line.substring(881, 886);
	String LANGUAGE_SPOKEN = line.substring(886, 888);
	String LANGUAGE_WRITTEN = line.substring(888, 890);
	String ETHNICITY = line.substring(890, 892);
	String EMPR_MDCR_IN = line.substring(892, 893);
	String member_Exchange_Id = line.substring(893, 943);
	String subscriber_Exchange_Id = line.substring(943, 993);
	String coverage_attribute = line.substring(1136, 1138);
	String tobacco_Use_Indicator = line.substring(993, 994);
	String tobacco_Use_Indicator_effective_date = line.substring(994, 1002);
	String subsidy_Indicator = line.substring(1002, 1003);
	String TAP_COVERAGE_PREMIUM_RATE_EXCHANGE_CSR_AMOUNT = line.substring(1162, 1166);
	String subsidy_Indicator_effective_date = line.substring(1003, 1011);
	String Max_TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE = line.substring(1138, 1146);
	String TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_END_DATE = line.substring(1146, 1154);
	String TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE = line.substring(1154, 1162);
	String individual_Email_address = line.substring(1056, 1136);

	ObjectMapper objectMapper = new ObjectMapper();
	JSONObject jsonObject = new JSONObject(objectMapper.writeValueAsString(new EnrollmentFieldsDatahub(
		NEDIRecordType, exchangeType, batch_Ref_834, NEDI_Batch_Generated_Time, NEDI_Batch_Processing_Time,
		NEDITOMAG_Record_Length, KAISER_REGION, RECORD_TYPE, RMS_GROUP_NO, RMS_SUBGROUP, RMS_BILLGROUP,
		EXCHANGE_QHP_ID, CONTRACT, CONTRACT_OPTION1, CONTRACT_OPTION2, CONTRACT_OPTION3, ACTIVITY_DATE,
		MAINT_TYPE_CODE_Health_Coverage_834, TRANS_TYPE_3, RECORD_CODE_3, MRN_PREFIX_3, MRN_HRN, FAN_PREFIX,
		FAN, MEDI_CAL_NBR, LAST_NAME, FIRST_NAME, MIDDLE_NAME, PREFIX_NAME, TITLE_NAME, DISPLAY_NAME,
		ACCOUNT_ROLE, SUBSCRIBERLESS_FLAG, BIRTH_DATE, MARITAL_STATUS, GENDER_CODE, MEDICARE_STATUS,
		SPECIAL_DEP_STATUS_Student, SPECIAL_DEP_STATUS_Handicap, NBR_IN_FAMILY, SUB_SSN, MEM_SSN,
		SUB_EMPL_ID_SUP, SUB_EMPL_ID, SUPPLEMENTAL_ID, FS_EMPLOYER_ID, EMPLOYER_NAME, EMPLOY_STATUS, HIRE_DATE,
		HOME_PHONE, HOME_PHONE_EXTENSION, WORK_PHONE, WORK_PHONE_EXTENSION, OCCUPATIONAL_TITLE, ADDRESS_1,
		ADDRESS_2, CARE_OF, CITY, COUNTY, STATE, ZIP_CODE_1, ZIP_CODE_2, COUNTRY, ENROLL_REASON, ENR_START_DATE,
		SIGNATURE_DATE, TERM_REASON, TERM_EFF_DATE, COBRA_MONTHS, COBRA_EFF_DATE, CUR_ELIGIBILITY, CUR_DUES_AMT,
		CUR_COVERAGE_LEVEL_CODE, LANGUAGE_SPOKEN, LANGUAGE_WRITTEN, ETHNICITY, EMPR_MDCR_IN, member_Exchange_Id,
		subscriber_Exchange_Id, coverage_attribute, tobacco_Use_Indicator, tobacco_Use_Indicator_effective_date,
		subsidy_Indicator, TAP_COVERAGE_PREMIUM_RATE_EXCHANGE_CSR_AMOUNT, subsidy_Indicator_effective_date,
		Max_TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE, TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_END_DATE,
		TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE, individual_Email_address)));
	return jsonObject;
    }

    public static List<EnrollmentFieldsDatahub> readInboundFileAndGetEnrollmentDTO(String fileName)
	    throws IOException, JSONException {

	List<EnrollmentFieldsDatahub> datahubObjectList = new ArrayList<EnrollmentFieldsDatahub>();

	InputStream is = ContextLoaderUtil.getResourceAsStream(fileName, FlatFileToDTOUtil.class);
	String line;
	try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {

	    // read line by line
	    while ((line = br.readLine()) != null) {
		System.out.println(line);
		datahubObjectList.add(convertFlatFileToDTO(line));

	    }
	}
	// read file line by line

	return datahubObjectList;
    }

    public static EnrollmentFieldsDatahub convertFlatFileToDTO(String line)
	    throws JsonProcessingException, JSONException {

	String NEDIRecordType = line.substring(0, 1);
	String exchangeType = line.substring(1, 5);
	String batch_Ref_834 = line.substring(5, 25);
	String NEDI_Batch_Generated_Time = line.substring(25, 45);
	String NEDI_Batch_Processing_Time = line.substring(45, 65);
	String NEDITOMAG_Record_Length = line.substring(65, 70);
	String KAISER_REGION = line.substring(70, 73);
	String RECORD_TYPE = line.substring(73, 74);
	String RMS_GROUP_NO = line.substring(74, 83);
	String RMS_SUBGROUP = line.substring(83, 87);
	String RMS_BILLGROUP = line.substring(87, 89);
	String EXCHANGE_QHP_ID = line.substring(89, 109);
	String CONTRACT = line.substring(109, 118);
	String CONTRACT_OPTION1 = line.substring(118, 127);
	String CONTRACT_OPTION2 = line.substring(127, 136);
	String CONTRACT_OPTION3 = line.substring(136, 145);
	String ACTIVITY_DATE = line.substring(145, 153);
	String MAINT_TYPE_CODE_Health_Coverage_834 = line.substring(153, 156);
	String TRANS_TYPE_3 = line.substring(156, 157);
	String RECORD_CODE_3 = line.substring(157, 158);
	String MRN_PREFIX_3 = line.substring(158, 160);
	String MRN_HRN = line.substring(160, 170);

	String FAN_PREFIX = line.substring(170, 172);
	String FAN = line.substring(172, 182);
	String MEDI_CAL_NBR = line.substring(182, 196);
	String LAST_NAME = line.substring(196, 221);
	String FIRST_NAME = line.substring(221, 246);
	String MIDDLE_NAME = line.substring(246, 271);
	String PREFIX_NAME = line.substring(271, 283);
	String TITLE_NAME = line.substring(283, 295);
	String DISPLAY_NAME = line.substring(295, 328);
	String ACCOUNT_ROLE = line.substring(328, 340);
	String SUBSCRIBERLESS_FLAG = line.substring(340, 341);
	String BIRTH_DATE = line.substring(341, 349);
	String MARITAL_STATUS = line.substring(349, 361);
	String GENDER_CODE = line.substring(361, 368);
	String MEDICARE_STATUS = line.substring(368, 369);
	String SPECIAL_DEP_STATUS_Student = line.substring(369, 370);
	String SPECIAL_DEP_STATUS_Handicap = line.substring(370, 371);
	String NBR_IN_FAMILY = line.substring(371, 373);
	String SUB_SSN = line.substring(373, 382);
	String MEM_SSN = line.substring(382, 391);
	String SUB_EMPL_ID_SUP = line.substring(391, 393);
	String SUB_EMPL_ID = line.substring(393, 402);
	String SUPPLEMENTAL_ID = line.substring(402, 418);
	String FS_EMPLOYER_ID = line.substring(418, 422);
	String EMPLOYER_NAME = line.substring(422, 482);
	String EMPLOY_STATUS = line.substring(482, 489);
	String HIRE_DATE = line.substring(489, 497);
	String HOME_PHONE = line.substring(497, 507);
	String HOME_PHONE_EXTENSION = line.substring(507, 512);
	String WORK_PHONE = line.substring(512, 522);
	String WORK_PHONE_EXTENSION = line.substring(522, 527);
	String OCCUPATIONAL_TITLE = line.substring(527, 557);
	String ADDRESS_1 = line.substring(557, 597);
	String ADDRESS_2 = line.substring(597, 637);
	String CARE_OF = line.substring(637, 667);
	String CITY = line.substring(667, 712);
	String COUNTY = line.substring(712, 757);
	String STATE = line.substring(757, 759);
	String ZIP_CODE_1 = line.substring(759, 766);
	String ZIP_CODE_2 = line.substring(766, 770);
	String COUNTRY = line.substring(770, 815);
	String ENROLL_REASON = line.substring(815, 827);
	String ENR_START_DATE = line.substring(827, 835);
	String SIGNATURE_DATE = line.substring(835, 843);
	String TERM_REASON = line.substring(843, 855);
	String TERM_EFF_DATE = line.substring(855, 863);
	String COBRA_MONTHS = line.substring(863, 865);
	String COBRA_EFF_DATE = line.substring(865, 873);
	String CUR_ELIGIBILITY = line.substring(873, 874);
	String CUR_DUES_AMT = line.substring(874, 881);
	String CUR_COVERAGE_LEVEL_CODE = line.substring(881, 886);
	String LANGUAGE_SPOKEN = line.substring(886, 888);
	String LANGUAGE_WRITTEN = line.substring(888, 890);
	String ETHNICITY = line.substring(890, 892);
	String EMPR_MDCR_IN = line.substring(892, 893);
	String member_Exchange_Id = line.substring(893, 943);
	String subscriber_Exchange_Id = line.substring(943, 993);
	String coverage_attribute = line.substring(1136, 1138);
	String tobacco_Use_Indicator = line.substring(993, 994);
	String tobacco_Use_Indicator_effective_date = line.substring(994, 1002);
	String subsidy_Indicator = line.substring(1002, 1003);
	String TAP_COVERAGE_PREMIUM_RATE_EXCHANGE_CSR_AMOUNT = line.substring(1162, 1166);
	String subsidy_Indicator_effective_date = line.substring(1003, 1011);
	String Max_TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE = line.substring(1138, 1146);
	String TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_END_DATE = line.substring(1146, 1154);
	String TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE = line.substring(1154, 1162);
	String individual_Email_address = line.substring(1056, 1136);

	return new EnrollmentFieldsDatahub(NEDIRecordType, exchangeType, batch_Ref_834, NEDI_Batch_Generated_Time,
		NEDI_Batch_Processing_Time, NEDITOMAG_Record_Length, KAISER_REGION, RECORD_TYPE, RMS_GROUP_NO,
		RMS_SUBGROUP, RMS_BILLGROUP, EXCHANGE_QHP_ID, CONTRACT, CONTRACT_OPTION1, CONTRACT_OPTION2,
		CONTRACT_OPTION3, ACTIVITY_DATE, MAINT_TYPE_CODE_Health_Coverage_834, TRANS_TYPE_3, RECORD_CODE_3,
		MRN_PREFIX_3, MRN_HRN, FAN_PREFIX, FAN, MEDI_CAL_NBR, LAST_NAME, FIRST_NAME, MIDDLE_NAME, PREFIX_NAME,
		TITLE_NAME, DISPLAY_NAME, ACCOUNT_ROLE, SUBSCRIBERLESS_FLAG, BIRTH_DATE, MARITAL_STATUS, GENDER_CODE,
		MEDICARE_STATUS, SPECIAL_DEP_STATUS_Student, SPECIAL_DEP_STATUS_Handicap, NBR_IN_FAMILY, SUB_SSN,
		MEM_SSN, SUB_EMPL_ID_SUP, SUB_EMPL_ID, SUPPLEMENTAL_ID, FS_EMPLOYER_ID, EMPLOYER_NAME, EMPLOY_STATUS,
		HIRE_DATE, HOME_PHONE, HOME_PHONE_EXTENSION, WORK_PHONE, WORK_PHONE_EXTENSION, OCCUPATIONAL_TITLE,
		ADDRESS_1, ADDRESS_2, CARE_OF, CITY, COUNTY, STATE, ZIP_CODE_1, ZIP_CODE_2, COUNTRY, ENROLL_REASON,
		ENR_START_DATE, SIGNATURE_DATE, TERM_REASON, TERM_EFF_DATE, COBRA_MONTHS, COBRA_EFF_DATE,
		CUR_ELIGIBILITY, CUR_DUES_AMT, CUR_COVERAGE_LEVEL_CODE, LANGUAGE_SPOKEN, LANGUAGE_WRITTEN, ETHNICITY,
		EMPR_MDCR_IN, member_Exchange_Id, subscriber_Exchange_Id, coverage_attribute, tobacco_Use_Indicator,
		tobacco_Use_Indicator_effective_date, subsidy_Indicator, TAP_COVERAGE_PREMIUM_RATE_EXCHANGE_CSR_AMOUNT,
		subsidy_Indicator_effective_date, Max_TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE,
		TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_END_DATE, TAP_COVERAGE_PREMIUM_RATE_EFFECTIVE_START_DATE,
		individual_Email_address);
    }
}
