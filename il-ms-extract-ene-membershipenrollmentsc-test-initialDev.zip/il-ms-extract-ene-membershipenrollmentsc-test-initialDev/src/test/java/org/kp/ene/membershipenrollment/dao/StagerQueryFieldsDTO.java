package org.kp.ene.membershipenrollment.dao;

public class StagerQueryFieldsDTO {
    private String tc_region_code;
    private String tpm_region_code;
    private String regional_customer_id;
    private String eligibility_subgroup_id;
    private String contract_id;
    private String person_rel_to_subscriber_code;
    private String subscriber_id;
    private String person_id;
    private String mrn;
    private String last_name;
    private String first_name;
    private String middle_name;
    private String person_covered;
    private String birth_date;
    private String marital_status_code;
    private String legal_sex_code;
    private String identification_type_code;
    private String identification_value;
    private String mpid;
    private String phone_number;
    private String extension;
    private String address_line_1;
    private String address_line_2;
    private String city;
    private String county_code;
    private String state_code;
    private String postal_code;
    private String country_code;
    private String person_enroll_reason_code;
    private String person_application_date;
    private String person_term_reason_code;
    private String tpc_effectivde_start_date;
    private String tpc_effective_end_date;
    private String language_code;
    private String language_type_code;
    private String ethnicity_code;
    private String group_member_id;
    private String group_subscriber_id;
    private String person_coverage_attribute;
    private String pca_eff_start_date;
    private String email_address;
    private String exchange_csr_amount;
    private String tc_coverage_start_date;
    private String tc_coverage_end_date;
    private String market_segment_type_code;
    private String market_segment_subtype_code;
    private String max_effective_start_date;

    public StagerQueryFieldsDTO() {
	// TODO Auto-generated constructor stub
    }

    public StagerQueryFieldsDTO(String tc_region_code, String tpm_region_code, String regional_customer_id,
	    String eligibility_subgroup_id, String contract_id, String person_rel_to_subscriber_code,
	    String subscriber_id, String person_id, String mrn, String last_name, String first_name, String middle_name,
	    String person_covered, String birth_date, String marital_status_code, String legal_sex_code,
	    String identification_type_code, String identification_value, String mpid, String phone_number,
	    String extension, String address_line_1, String address_line_2, String city, String county_code,
	    String state_code, String postal_code, String country_code, String person_enroll_reason_code,
	    String person_application_date, String person_term_reason_code, String tpc_effectivde_start_date,
	    String tpc_effective_end_date, String language_code, String language_type_code, String ethnicity_code,
	    String group_member_id, String group_subscriber_id, String person_coverage_attribute,
	    String pca_eff_start_date, String email_address, String exchange_csr_amount, String tc_coverage_start_date,
	    String tc_coverage_end_date, String market_segment_type_code, String market_segment_subtype_code,
	    String max_effective_start_date) {
	super();
	this.tc_region_code = tc_region_code;
	this.tpm_region_code = tpm_region_code;
	this.regional_customer_id = regional_customer_id;
	this.eligibility_subgroup_id = eligibility_subgroup_id;
	this.contract_id = contract_id;
	this.person_rel_to_subscriber_code = person_rel_to_subscriber_code;
	this.subscriber_id = subscriber_id;
	this.person_id = person_id;
	this.mrn = mrn;
	this.last_name = last_name;
	this.first_name = first_name;
	this.middle_name = middle_name;
	this.person_covered = person_covered;
	this.birth_date = birth_date;
	this.marital_status_code = marital_status_code;
	this.legal_sex_code = legal_sex_code;
	this.identification_type_code = identification_type_code;
	this.identification_value = identification_value;
	this.mpid = mpid;
	this.phone_number = phone_number;
	this.extension = extension;
	this.address_line_1 = address_line_1;
	this.address_line_2 = address_line_2;
	this.city = city;
	this.county_code = county_code;
	this.state_code = state_code;
	this.postal_code = postal_code;
	this.country_code = country_code;
	this.person_enroll_reason_code = person_enroll_reason_code;
	this.person_application_date = person_application_date;
	this.person_term_reason_code = person_term_reason_code;
	this.tpc_effectivde_start_date = tpc_effectivde_start_date;
	this.tpc_effective_end_date = tpc_effective_end_date;
	this.language_code = language_code;
	this.language_type_code = language_type_code;
	this.ethnicity_code = ethnicity_code;
	this.group_member_id = group_member_id;
	this.group_subscriber_id = group_subscriber_id;
	this.person_coverage_attribute = person_coverage_attribute;
	this.pca_eff_start_date = pca_eff_start_date;
	this.email_address = email_address;
	this.exchange_csr_amount = exchange_csr_amount;
	this.tc_coverage_start_date = tc_coverage_start_date;
	this.tc_coverage_end_date = tc_coverage_end_date;
	this.market_segment_type_code = market_segment_type_code;
	this.market_segment_subtype_code = market_segment_subtype_code;
	this.max_effective_start_date = max_effective_start_date;
    }

    public String getTc_region_code() {
	return tc_region_code;
    }

    public void setTc_region_code(String tc_region_code) {
	this.tc_region_code = tc_region_code;
    }

    public String getTpm_region_code() {
	return tpm_region_code;
    }

    public void setTpm_region_code(String tpm_region_code) {
	this.tpm_region_code = tpm_region_code;
    }

    public String getRegional_customer_id() {
	return regional_customer_id;
    }

    public void setRegional_customer_id(String regional_customer_id) {
	this.regional_customer_id = regional_customer_id;
    }

    public String getEligibility_subgroup_id() {
	return eligibility_subgroup_id;
    }

    public void setEligibility_subgroup_id(String eligibility_subgroup_id) {
	this.eligibility_subgroup_id = eligibility_subgroup_id;
    }

    public String getContract_id() {
	return contract_id;
    }

    public void setContract_id(String contract_id) {
	this.contract_id = contract_id;
    }

    public String getPerson_rel_to_subscriber_code() {
	return person_rel_to_subscriber_code;
    }

    public void setPerson_rel_to_subscriber_code(String person_rel_to_subscriber_code) {
	this.person_rel_to_subscriber_code = person_rel_to_subscriber_code;
    }

    public String getSubscriber_id() {
	return subscriber_id;
    }

    public void setSubscriber_id(String subscriber_id) {
	this.subscriber_id = subscriber_id;
    }

    public String getPerson_id() {
	return person_id;
    }

    public void setPerson_id(String person_id) {
	this.person_id = person_id;
    }

    public String getMrn() {
	return mrn;
    }

    public void setMrn(String mrn) {
	this.mrn = mrn;
    }

    public String getLast_name() {
	return last_name;
    }

    public void setLast_name(String last_name) {
	this.last_name = last_name;
    }

    public String getFirst_name() {
	return first_name;
    }

    public void setFirst_name(String first_name) {
	this.first_name = first_name;
    }

    public String getMiddle_name() {
	return middle_name;
    }

    public void setMiddle_name(String middle_name) {
	this.middle_name = middle_name;
    }

    public String getPerson_covered() {
	return person_covered;
    }

    public void setPerson_covered(String person_covered) {
	this.person_covered = person_covered;
    }

    public String getBirth_date() {
	return birth_date;
    }

    public void setBirth_date(String birth_date) {
	this.birth_date = birth_date;
    }

    public String getMarital_status_code() {
	return marital_status_code;
    }

    public void setMarital_status_code(String marital_status_code) {
	this.marital_status_code = marital_status_code;
    }

    public String getLegal_sex_code() {
	return legal_sex_code;
    }

    public void setLegal_sex_code(String legal_sex_code) {
	this.legal_sex_code = legal_sex_code;
    }

    public String getIdentification_type_code() {
	return identification_type_code;
    }

    public void setIdentification_type_code(String identification_type_code) {
	this.identification_type_code = identification_type_code;
    }

    public String getIdentification_value() {
	return identification_value;
    }

    public void setIdentification_value(String identification_value) {
	this.identification_value = identification_value;
    }

    public String getMpid() {
	return mpid;
    }

    public void setMpid(String mpid) {
	this.mpid = mpid;
    }

    public String getPhone_number() {
	return phone_number;
    }

    public void setPhone_number(String phone_number) {
	this.phone_number = phone_number;
    }

    public String getExtension() {
	return extension;
    }

    public void setExtension(String extension) {
	this.extension = extension;
    }

    public String getAddress_line_1() {
	return address_line_1;
    }

    public void setAddress_line_1(String address_line_1) {
	this.address_line_1 = address_line_1;
    }

    public String getAddress_line_2() {
	return address_line_2;
    }

    public void setAddress_line_2(String address_line_2) {
	this.address_line_2 = address_line_2;
    }

    public String getCity() {
	return city;
    }

    public void setCity(String city) {
	this.city = city;
    }

    public String getCounty_code() {
	return county_code;
    }

    public void setCounty_code(String county_code) {
	this.county_code = county_code;
    }

    public String getState_code() {
	return state_code;
    }

    public void setState_code(String state_code) {
	this.state_code = state_code;
    }

    public String getPostal_code() {
	return postal_code;
    }

    public void setPostal_code(String postal_code) {
	this.postal_code = postal_code;
    }

    public String getCountry_code() {
	return country_code;
    }

    public void setCountry_code(String country_code) {
	this.country_code = country_code;
    }

    public String getPerson_enroll_reason_code() {
	return person_enroll_reason_code;
    }

    public void setPerson_enroll_reason_code(String person_enroll_reason_code) {
	this.person_enroll_reason_code = person_enroll_reason_code;
    }

    public String getPerson_application_date() {
	return person_application_date;
    }

    public void setPerson_application_date(String person_application_date) {
	this.person_application_date = person_application_date;
    }

    public String getPerson_term_reason_code() {
	return person_term_reason_code;
    }

    public void setPerson_term_reason_code(String person_term_reason_code) {
	this.person_term_reason_code = person_term_reason_code;
    }

    public String getTpc_effectivde_start_date() {
	return tpc_effectivde_start_date;
    }

    public void setTpc_effectivde_start_date(String tpc_effectivde_start_date) {
	this.tpc_effectivde_start_date = tpc_effectivde_start_date;
    }

    public String getTpc_effective_end_date() {
	return tpc_effective_end_date;
    }

    public void setTpc_effective_end_date(String tpc_effective_end_date) {
	this.tpc_effective_end_date = tpc_effective_end_date;
    }

    public String getLanguage_code() {
	return language_code;
    }

    public void setLanguage_code(String language_code) {
	this.language_code = language_code;
    }

    public String getLanguage_type_code() {
	return language_type_code;
    }

    public void setLanguage_type_code(String language_type_code) {
	this.language_type_code = language_type_code;
    }

    public String getEthnicity_code() {
	return ethnicity_code;
    }

    public void setEthnicity_code(String ethnicity_code) {
	this.ethnicity_code = ethnicity_code;
    }

    public String getGroup_member_id() {
	return group_member_id;
    }

    public void setGroup_member_id(String group_member_id) {
	this.group_member_id = group_member_id;
    }

    public String getGroup_subscriber_id() {
	return group_subscriber_id;
    }

    public void setGroup_subscriber_id(String group_subscriber_id) {
	this.group_subscriber_id = group_subscriber_id;
    }

    public String getPerson_coverage_attribute() {
	return person_coverage_attribute;
    }

    public void setPerson_coverage_attribute(String person_coverage_attribute) {
	this.person_coverage_attribute = person_coverage_attribute;
    }

    public String getPca_eff_start_date() {
	return pca_eff_start_date;
    }

    public void setPca_eff_start_date(String pca_eff_start_date) {
	this.pca_eff_start_date = pca_eff_start_date;
    }

    public String getEmail_address() {
	return email_address;
    }

    public void setEmail_address(String email_address) {
	this.email_address = email_address;
    }

    public String getExchange_csr_amount() {
	return exchange_csr_amount;
    }

    public void setExchange_csr_amount(String exchange_crs_amount) {
	this.exchange_csr_amount = exchange_crs_amount;
    }

    public String getTc_coverage_start_date() {
	return tc_coverage_start_date;
    }

    public void setTc_coverage_start_date(String tc_coverage_start_date) {
	this.tc_coverage_start_date = tc_coverage_start_date;
    }

    public String getTc_coverage_end_date() {
	return tc_coverage_end_date;
    }

    public void setTc_coverage_end_date(String tc_coverage_end_date) {
	this.tc_coverage_end_date = tc_coverage_end_date;
    }

    public String getMarket_segment_type_code() {
	return market_segment_type_code;
    }

    public void setMarket_segment_type_code(String market_segment_type_code) {
	this.market_segment_type_code = market_segment_type_code;
    }

    public String getMarket_segment_subtype_code() {
	return market_segment_subtype_code;
    }

    public void setMarket_segment_subtype_code(String market_segment_subtype_code) {
	this.market_segment_subtype_code = market_segment_subtype_code;
    }

    public String getMax_effective_start_date() {
	return max_effective_start_date;
    }

    public void setMax_effective_start_date(String max_effective_start_date) {
	this.max_effective_start_date = max_effective_start_date;
    }
}
