package org.kp.ene.membershipenrollment.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class ExtractTestAutomationDaoImpl {

    Logger log = LoggerFactory.getLogger(ExtractTestAutomationDaoImpl.class);

    @Value("${sftp.jobName}")
    private String jobName;

    @Value("${extracts.test.dataowner}")
    private String dataOwner;

    private JdbcTemplate jdbcTemplate;

    public ExtractTestAutomationDaoImpl(JdbcTemplate jdbcTemplate) {
	this.jdbcTemplate = jdbcTemplate;
    }

    public List<StagerQueryFieldsDTO> getEnrollmentStageQueryResult(String mrn) {
	List<StagerQueryFieldsDTO> stageQueryDTO = new ArrayList<>();
	List<Map<String, Object>> rows = jdbcTemplate.queryForList(
		ExtractTestAutomationJDBCQueries.ENROLLMENT_STAGE_QUERY, new Object[] { mrn },
		new StagerQueryFieldsDTO());

	for (Map row : rows) {
	    StagerQueryFieldsDTO obj = new StagerQueryFieldsDTO();
	    obj.setMrn((String) row.get("MRN"));
	    stageQueryDTO.add(obj);
	}

	return stageQueryDTO;
    }

    public String getToValueFromCrossWalk(String domainCode, String applicationCode, String selectorCode,
	    String fromValue) {
	return this.jdbcTemplate.queryForObject(ExtractTestAutomationJDBCQueries.CROSSWALK_QUERY, String.class,
		domainCode, applicationCode, selectorCode, fromValue);
    }
}
