package org.kp.ene.membershipenrollment.dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class ExtractTestAutomationService {

    Logger log = LoggerFactory.getLogger(ExtractTestAutomationService.class);

    @Value("${sftp.inbound.local.directory:/}")
    private String localInboundDirectory;

    @Value("${extracts.test.dataowner:BILL_CMS_I820_COL}")
    private String dataOwner;

    @Value("${sftp.outbound.local.directory:/}")
    private String localOutboundDirectory;

    @Value("${extracts.outbound.filePattern:}")
    private String outboundFilePattern;

    @Autowired
    private ExtractTestAutomationDaoImpl sftpDaoImpl;

//    @Autowired
//    private ExtractTestAutomationDownloadFiles download;

}
