package org.kp.ene.membershipenrollment.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class EnrollmentStageQueryResultMapper implements RowMapper<StagerQueryFieldsDTO> {

    @Override
    public StagerQueryFieldsDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

	StagerQueryFieldsDTO stageDTO = new StagerQueryFieldsDTO();

	stageDTO.setTc_region_code(rs.getString("TC_REGION_CODE"));
	stageDTO.setTpm_region_code(rs.getString("TPM_REGION_CODE"));
	stageDTO.setRegional_customer_id(rs.getString("regional_customer_id"));
	stageDTO.setEligibility_subgroup_id(rs.getString("eligibility_subgroup_id"));
	stageDTO.setContract_id(rs.getString("contract_id"));
	stageDTO.setPerson_rel_to_subscriber_code(rs.getString("person_rel_to_subscriber_code"));
	stageDTO.setSubscriber_id(rs.getString("subscriber_id"));
	stageDTO.setPerson_id(rs.getString("person_id"));
	stageDTO.setMrn(rs.getString("mrn"));
	stageDTO.setLast_name(rs.getString("last_name"));
	stageDTO.setFirst_name(rs.getString("first_name"));
	stageDTO.setMiddle_name(rs.getString("middle_name"));
	stageDTO.setPerson_covered(rs.getString("person_covered"));
	stageDTO.setBirth_date(rs.getString("birth_date"));
	stageDTO.setMarital_status_code(rs.getString("marital_status_code"));
	stageDTO.setLegal_sex_code(rs.getString("legal_sex_code"));
	stageDTO.setIdentification_type_code(rs.getString("identification_type_code"));
	stageDTO.setIdentification_value(rs.getString("identification_value"));
	stageDTO.setMpid(rs.getString("mpid"));
	stageDTO.setPhone_number(rs.getString("phone_number"));
	stageDTO.setExtension(rs.getString("extension"));
	stageDTO.setAddress_line_1(rs.getString("address_line_1"));
	stageDTO.setAddress_line_2(rs.getString("address_line_2"));
	stageDTO.setCity(rs.getString("city"));
	stageDTO.setCounty_code(rs.getString("county_code"));
	stageDTO.setState_code(rs.getString("state_code"));
	stageDTO.setPostal_code(rs.getString("postal_code"));
	stageDTO.setCountry_code(rs.getString("country_code"));
	stageDTO.setPerson_enroll_reason_code(rs.getString("person_enroll_reason_code"));
	stageDTO.setPerson_application_date(rs.getString("person_application_date"));
	stageDTO.setPerson_term_reason_code(rs.getString("person_term_reason_code"));
	stageDTO.setTpc_effectivde_start_date(rs.getString("tpc_effectivde_start_date"));
	stageDTO.setTpc_effective_end_date(rs.getString("tpc_effective_end_date"));
	stageDTO.setLanguage_code(rs.getString("language_code"));
	stageDTO.setLanguage_type_code(rs.getString("language_type_code"));
	stageDTO.setEthnicity_code(rs.getString("ethnicity_code"));
	stageDTO.setGroup_member_id(rs.getString("group_member_id"));
	stageDTO.setGroup_subscriber_id(rs.getString("group_subscriber_id"));
	stageDTO.setPerson_coverage_attribute(rs.getString("person_coverage_attribute"));
	stageDTO.setPca_eff_start_date(rs.getString("pca_eff_start_date"));
	stageDTO.setEmail_address(rs.getString("email_address"));
	stageDTO.setExchange_csr_amount(rs.getString("exchange_csr_amount"));
	stageDTO.setTc_coverage_start_date(rs.getString("tc_coverage_start_date"));
	stageDTO.setTc_coverage_end_date(rs.getString("tc_coverage_end_date"));
	stageDTO.setMarket_segment_type_code(rs.getString("market_segment_type_code"));
	stageDTO.setMarket_segment_subtype_code(rs.getString("market_segment_subtype_code"));
	stageDTO.setMax_effective_start_date(rs.getString("max_effective_start_date"));
	return stageDTO;
    }
}
