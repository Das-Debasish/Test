package org.kp.ene.membershipenrollment.dao;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

public class ContextLoaderUtil {

	public static URL getResources(String resourceName, @SuppressWarnings("rawtypes") Class callingClass) {
		URL url = Thread.currentThread().getContextClassLoader().getResource(resourceName);
		if (url == null) {
			url = ContextLoaderUtil.class.getClassLoader().getResource(resourceName);
		}

		if (url == null) {
			ClassLoader cl = callingClass.getClassLoader();
			if (cl != null) {
				url = cl.getResource(resourceName);
			}
		}

		if ((url == null) && (resourceName != null) && (resourceName.charAt(0) != '/')) {
			return null;
		}

		return url;
	}
	
	public static InputStream getResourceAsStream(String resourceName, @SuppressWarnings("rawtypes") Class callingClass)
	{
		URL url = getResources(resourceName, callingClass);
		try
		{
			return(url != null) ? url.openStream() : null;
		}
		catch(IOException e)
		{
			return null;
		}
	}
}
