function fn(){
	var keyEnv = karate.env;
	var config = {
		refFileNameLocation: "src/main/resources/",
		refFilename:"TestReferenceFile.xlsx",
		outBoundFileLocation: "src/main/resources/outbound/",
		driverClassName: "",
		url: "",
		username: "",
		password: "",
};	
if(keyEnv=='JPT'){
	config.driverClassName="oracle.jdbc.OracleDriver";
	config.url = "jdbc:oracle:thin:@//scan-pzendb181x.pldc.kp.org:1521/MCHUBDV3.pldc.kp.org";
	config.username = "appuser";
	config.password = "Kpifapps123";
}else if (keyEnv == 'DIT') {
	config.driverClassName="oracle.jdbc.OracleDriver";
	config.url = "jdbc:oracle:thin:@//scan-pzendb181x.pldc.kp.org:1521/MCHUBDV3.pldc.kp.org";
	config.username = "appuser";
	config.password = "Kpifapps123";
}else {
	config.driverClassName="oracle.jdbc.OracleDriver";
	config.url = "jdbc:oracle:thin:@//scan-pzendb181x.pldc.kp.org:1521/MCHUBDV3.pldc.kp.org";
	config.username = "appuser";
	config.password = "Kpifapps123";
}
return config;
	
}
