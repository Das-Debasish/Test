package org.kp.dcreport;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.sql.DataSource;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONException;
import org.json.JSONObject;
import org.kp.kpmc.extract.automation.dao.ExtractTestAutomationDaoImpl;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.jdbc.core.JdbcTemplate;

public class Int158Utils {

	ExtractTestAutomationDaoImpl extractTestAutomationDaoImpl;

	JdbcTemplate jdbcTemplate;

	public Int158Utils(String driverClassName, String url, String username, String password) {
		jdbcTemplate = new JdbcTemplate(getDataSource(driverClassName, url, username, password));
		extractTestAutomationDaoImpl = new ExtractTestAutomationDaoImpl(jdbcTemplate);
	}

	public DataSource getDataSource(String driverClassName, String url, String username, String password) {

		DataSourceBuilder dataSourceBuilder = DataSourceBuilder.create();
		dataSourceBuilder.driverClassName(driverClassName);
		dataSourceBuilder.url(url);
		dataSourceBuilder.username(username);
		dataSourceBuilder.password(password);
		return dataSourceBuilder.build();
	}

	public String getOutBoundFileName(String filePath) throws Exception {
		File outDirectoryy = new File(filePath);
		boolean flag = true;
		File[] fileArray = null;
		String fileName = null;
		for (int count = 0; count < 10 && flag == true;) {
			try {
				fileArray = outDirectoryy.listFiles();
				if (fileArray != null && fileArray.length > 0) {
					String[] containingFileNames = outDirectoryy.list();
					for (String file : containingFileNames) {
						if (file.contains(".xlsx")) {
							fileName = file;
							flag = false;
						}
					}
				} else {
					System.out.println("Waiting for Files to be present");
					Thread.sleep(1000);
					count++;
				}
			} catch (Exception e) {

			}
		}
		if (flag)
			throw new Exception("Output file is not found after 600 retries with 2 seconds of intervals");

		return fileName;

	}

	public static boolean fileNamingConvention(String filename) {
		final String FILE_PATTERN = "834_Recon_KFMASI_DC0_[0-9]{8}_1.xlsx";
		final Pattern pattern = Pattern.compile(FILE_PATTERN);
		Matcher matcher = pattern.matcher(filename);
		return matcher.matches() == true ? true : false;
	}

	public static ArrayList<String> verifyErrorCodeMatchingErrorMessage(String filename) {
		File file = new File(filename);
		FileInputStream fis;
		HashMap<String, String> errormsgwitherrorcode = new HashMap<>();
		errormsgwitherrorcode.put("ENR001", "Exchange-assigned member ID");
		errormsgwitherrorcode.put("ENR003", "DOB");
		errormsgwitherrorcode.put("ENR007", "SSN");
		errormsgwitherrorcode.put("ENR015", "Address");
		errormsgwitherrorcode.put("ENR016", "Last Name");
		errormsgwitherrorcode.put("ENR018", "First Name");
		errormsgwitherrorcode.put("ENR026", "Broker missing or NPN mismatch");
		errormsgwitherrorcode.put("ENR027", "Relationship");
		errormsgwitherrorcode.put("ENR040", "Start Date");
		errormsgwitherrorcode.put("ENR045", "Total Premimum");
		errormsgwitherrorcode.put("ENR046", "APTC");
		errormsgwitherrorcode.put("ENR059", "Exchange-assigned subscriber ID");
		errormsgwitherrorcode.put("ENR062", "Gender");
		errormsgwitherrorcode.put("ENR065", "QHPID");
		errormsgwitherrorcode.put("ENR071", "DNX Carrier");
		errormsgwitherrorcode.put("ENR072", "DNX HBX");
		errormsgwitherrorcode.put("ENR077", "Benefit end date");
		errormsgwitherrorcode.put("ENR999", "OTHER");
		ArrayList<String> errormessage = new ArrayList<>();
		try {
			fis = new FileInputStream(file);
			Workbook workbook = WorkbookFactory.create(fis);
			Sheet sheet = workbook.getSheet("Summary");
			for (int i = 0; i < sheet.getLastRowNum(); i++) {
				String errorcode = sheet.getRow(i + 1).getCell(0).toString().trim();
				String errormsg = sheet.getRow(i + 1).getCell(1).toString().trim();
				if (errormsg.equalsIgnoreCase("Total")) {
					break;
				}
				if (!errormsg.equalsIgnoreCase(errormsgwitherrorcode.get(errorcode))) {
					errormessage.add(errormsg);
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return errormessage;

	}

	public static HashMap<String, Integer> getErrormessageWithCount(String filename) {

		File file = new File(filename);
		FileInputStream fis;
		HashMap<String, Integer> errormsgwithcount = new HashMap<>();
		try {
			fis = new FileInputStream(file);
			Workbook workbook = WorkbookFactory.create(fis);
			Sheet sheet = workbook.getSheet("Summary");
			for (int i = 0; i < sheet.getLastRowNum(); i++) {
				String key = sheet.getRow(i + 1).getCell(1).toString().trim();
				if (key.equalsIgnoreCase("Broker missing or NPN mismatch")) {
					key = "Broker NPN";
				}
				if (key.equalsIgnoreCase("Total")) {
					break;
				}
				String count = sheet.getRow(i + 1).getCell(2).toString();
				int value = (int) Float.parseFloat(count);
				errormsgwithcount.put(key, value);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return errormsgwithcount;

	}

	public static ArrayList<String> verifyRecordCountinSheet(String filename) {

		File file = new File(filename);
		FileInputStream fis;
		ArrayList<String> sheetnames = new ArrayList<>();
		HashMap<String, Integer> errormsgwithcount = new HashMap<>();
		errormsgwithcount = getErrormessageWithCount(filename);
		try {
			fis = new FileInputStream(file);
			Workbook workbook = WorkbookFactory.create(fis);
			for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
				if (!workbook.getSheetName(i).equalsIgnoreCase("Summary")) {
					String sheetname = workbook.getSheetName(i);
					Sheet sheet = workbook.getSheet(sheetname);
					int sheetrowcount = sheet.getLastRowNum() - 1;
					int count = errormsgwithcount.get(sheetname);
					if (count != sheetrowcount) {
						sheetnames.add(sheetname);
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return sheetnames;
	}

	public static ArrayList<String> getSheetNames(String filename) {
		File file = new File(filename);
		FileInputStream fis;
		ArrayList<String> sheetnames = new ArrayList<>();
		try {
			fis = new FileInputStream(file);
			Workbook workbook = WorkbookFactory.create(fis);
			for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
				if (!workbook.getSheetName(i).equalsIgnoreCase("Summary"))
					sheetnames.add(workbook.getSheetName(i));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return sheetnames;
	}

	public static ArrayList<String> getSummaryErrorMessages(String filename) {

		File file = new File(filename);
		FileInputStream fis;
		ArrayList<String> error = new ArrayList<>();
		try {
			fis = new FileInputStream(file);
			Workbook workbook = WorkbookFactory.create(fis);
			Sheet sheet = workbook.getSheet("Summary");
			for (int i = 0; i < sheet.getLastRowNum(); i++) {
				String value = sheet.getRow(i + 1).getCell(1).toString().trim();
				if (value.equalsIgnoreCase("Broker missing or NPN mismatch")) {
					value = "Broker NPN";
				}
				if (value.equalsIgnoreCase("Total")) {
					break;
				}
				error.add(value);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return error;
	}

	public static ArrayList<String> getErrorCodes(String filename) {

		File file = new File(filename);
		FileInputStream fis;
		ArrayList<String> error = new ArrayList<>();
		try {
			fis = new FileInputStream(file);
			Workbook workbook = WorkbookFactory.create(fis);
			Sheet sheet = workbook.getSheet("Summary");
			for (int i = 0; i < sheet.getLastRowNum(); i++) {
				String value = sheet.getRow(i + 1).getCell(1).toString().trim();
				String errcode = sheet.getRow(i + 1).getCell(0).toString().trim();
				if (value.equalsIgnoreCase("Total")) {
					break;
				}
				error.add(errcode);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return error;
	}

	public static List<String> getHeaders(String filename, String sheetname) {

		File file = new File(filename);
		FileInputStream fis;
		List<String> values = new ArrayList<>();
		String headers[] = { "Carrier ID", "Plan Sponsor ID", "Error Code", "Error Message", "HBX Subscriber ID",
				"HBX Member ID", "HBX Policy #", "SSN", "Last Name", "First Name", "Relationship", "Date of Birth",
				"Benefit Begin Date", "Benefit End Date", "Exchange Value", "Carrier Value", "Comments" };

		List<String> headerslist = Arrays.asList(headers);
		List<String> mismatchHeaders = new ArrayList<>();
		try {
			fis = new FileInputStream(file);
			Workbook workbook = WorkbookFactory.create(fis);
			Sheet sheet = workbook.getSheet(sheetname);
			for (int i = 0; i < sheet.getRow(1).getLastCellNum(); i++) {
				String headerValue = sheet.getRow(1).getCell(i).toString().trim();
				values.add(headerValue);
			}
			Collections.sort(headerslist);
			Collections.sort(values);
			for (int i = 0; i < headerslist.size(); i++) {
				if (!headerslist.get(i).equals(values.get(i))) {
					mismatchHeaders.add(values.get(i));
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mismatchHeaders;
	}

	public static String getJsonFormat(String filename, String sheetname) {
		File file = new File(filename);
		FileInputStream fis;
		List<List<String>> sheetDataTable = null;
		Sheet sheet = null;
		String jsonString = null;
		try {
			fis = new FileInputStream(file);
			Workbook workbook = WorkbookFactory.create(fis);
			sheet = workbook.getSheet(sheetname);
			sheetDataTable = getSheetDataList(sheet);
			// Generate JSON format of above sheet data and write to a JSON file.
			jsonString = getJSONStringFromList(sheetDataTable);
		} catch (IOException | JSONException e) {
			e.printStackTrace();
		}
		return jsonString;
	}

	public static List<List<String>> getSheetDataList(Sheet sheet) {
		List<List<String>> ret = new ArrayList<List<String>>();
		// Get the first and last sheet row number.
		int firstRowNum = sheet.getFirstRowNum();
		int lastRowNum = sheet.getLastRowNum();
		if (lastRowNum > 0) { // Loop in sheet rows.
			for (int i = firstRowNum + 1; i < lastRowNum + 1; i++) {
				// Get current row object.
				Row row = sheet.getRow(i);
				// Get first and last cell number.
				int firstCellNum = row.getFirstCellNum();
				int lastCellNum = row.getLastCellNum();
				// Create a String list to save column data in a row.
				List<String> rowDataList = new ArrayList<String>();
				// Loop in the row cells.
				for (int j = firstCellNum; j < lastCellNum; j++) {
					// Get current cell.
					Cell cell = row.getCell(j);
					// Get cell type
					String cellValue = cell.getStringCellValue();
					rowDataList.add(cellValue);
				}
				// Add current row data list in the return list.
				ret.add(rowDataList);
			}
		}

		return ret;
	}

	private static String getJSONStringFromList(List<List<String>> dataTable) throws JSONException {
		String ret = "";
		if (dataTable != null) {
			int rowCount = dataTable.size();
			if (rowCount > 1) {
				// Create a JSONObject to store table data.
				JSONObject tableJsonObject = new JSONObject();
				// The first row is the header row, store each column name.
				List<String> headerRow = dataTable.get(0);
				int columnCount = headerRow.size();
				// Loop in the row data list.
				for (int i = 1; i < rowCount; i++) {
					// Get current row data.
					List<String> dataRow = dataTable.get(i);
					// Create a JSONObject object to store row data.
					JSONObject rowJsonObject = new JSONObject();
					for (int j = 0; j < columnCount; j++) {
						String columnName = headerRow.get(j);
						String columnValue = dataRow.get(j);
						rowJsonObject.put(columnName, columnValue);
					}
					tableJsonObject.put("Row " + i, rowJsonObject);
				}
				// Return string format data of JSONObject object.
				ret = tableJsonObject.toString();
			}
		}
		return ret;
	}
}
