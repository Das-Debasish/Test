package org.kp.dcreport;

import org.kp.kpmc.extract.automation.ExtractTestAutomationApplication;

import com.intuit.karate.junit5.Karate;

public class ExtractTestAutomationApplicationTests {

	@Karate.Test
	Karate testUsers() {

		String inputFileName = "834_20200505142122914Z_KFMASI_A_F_I_1.txt";
		ExtractTestAutomationApplication.main(new String[] { inputFileName });
		System.out.println("System varialbe: " + System.getProperty("env"));
		if (System.getProperty("env") == null)
			System.setProperty("karate.env", "DIT");
		else
			System.setProperty("karate.env", System.getProperty("env"));

		System.out.println("Start Test Cases===================>");
		return Karate.run("il-ene-dc-discrepancy-test-158").relativeTo(getClass());
		// return null;
	}
}
